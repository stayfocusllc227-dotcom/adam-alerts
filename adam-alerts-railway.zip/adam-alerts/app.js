const apiReady = {
  football: { provider: "API-Football", status: "ready" },
  odds: { provider: "The Odds API", status: "ready" },
  auth: { provider: "Firebase", status: "ready" },
  payments: ["MonCash", "NatCash", "Stripe", "PayPal", "Apple Pay", "Google Pay"],
  firebaseCollections: ["users", "subscriptions", "predictions", "expert_picks", "favorites", "notifications", "promo_codes"],
  aiInputs: [
    "Last 5 matches",
    "Team ranking",
    "Home/Away form",
    "Goals scored",
    "Goals conceded",
    "Head-to-head",
    "Odds movement",
  ],
  aiOutputs: ["1X2", "Over/Under 2.5", "BTTS", "Double chance", "Confidence %", "Risk", "French explanation"],
  endpoints: {
    fixtures: "/v3/fixtures",
    standings: "/v3/standings",
    odds: "/v3/odds",
    leagues: "/v3/leagues",
    teams: "/v3/teams",
  },
};

const API_FOOTBALL_BASE_URL = "https://v3.football.api-sports.io";
const API_FOOTBALL_REFRESH_MS = 60000;
const API_FOOTBALL_FALLBACK_KEY = "";
const ODDS_API_REFRESH_MS = 60000;
const AI_DEEP_ANALYSIS_ENABLED = true;
const FREE_AI_PICK_LIMIT = 3;

let apiFootballKey = "";
let apiFootballConnected = false;
let oddsApiConnected = false;
let oddsLastUpdated = "";
let oddsEvents = [];
let standingsData = [];
let standingsLeagueLabel = "";
let worldCupFixtures = [];
let aiEngineConnected = false;
const teamFormCache = new Map();
const h2hCache = new Map();
const standingsCache = new Map();
const detailHistoryCache = new Map();

const countryProfiles = {
  haiti: {
    label: "🇭🇹 Haïti",
    currency: "HTG / Gourdes",
    proPrice: "1000 GDES / mois",
    proPickPrice: "100 GDES",
    paymentMethods: ["MonCash", "NatCash"],
  },
  usa: {
    label: "🇺🇸 États-Unis",
    currency: "USD",
    proPrice: "$29.99 / mois",
    proPickPrice: "$4.99",
    paymentMethods: ["Stripe", "PayPal", "Apple Pay"],
  },
  other: {
    label: "🌍 Autre pays",
    currency: "USD",
    proPrice: "$29.99 / mois",
    proPickPrice: "$4.99",
    paymentMethods: ["Stripe", "PayPal", "Visa/Mastercard"],
  },
};

const footballServices = {
  apiFootball: {
    name: "API-Football",
    resources: ["Live matches", "Upcoming matches", "Team logos", "League logos", "Fixtures", "Standings", "World Cup 2026"],
    refreshMs: 60000,
    lastSync: null,
  },
  oddsApi: {
    name: "The Odds API",
    resources: ["1X2 odds", "Over/Under odds", "BTTS odds", "Best bookmaker odds"],
    refreshMs: 60000,
    lastSync: null,
  },
  refresh() {
    const stamp = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    this.apiFootball.lastSync = stamp;
    this.oddsApi.lastSync = stamp;
    document.querySelectorAll("[data-sync-time]").forEach((item) => {
      item.textContent = stamp;
    });
  },
};

const teamLogos = {
  "Paris SG": "https://media.api-sports.io/football/teams/85.png",
  Lyon: "https://media.api-sports.io/football/teams/80.png",
  Marseille: "https://media.api-sports.io/football/teams/81.png",
  Monaco: "https://media.api-sports.io/football/teams/91.png",
  Lille: "https://media.api-sports.io/football/teams/79.png",
  Rennes: "https://media.api-sports.io/football/teams/94.png",
  Nice: "https://media.api-sports.io/football/teams/84.png",
  Lens: "https://media.api-sports.io/football/teams/116.png",
  "Real Madrid": "https://media.api-sports.io/football/teams/541.png",
  Valence: "https://media.api-sports.io/football/teams/532.png",
  Barcelone: "https://media.api-sports.io/football/teams/529.png",
  "Séville": "https://media.api-sports.io/football/teams/536.png",
  Girona: "https://media.api-sports.io/football/teams/547.png",
  Villarreal: "https://media.api-sports.io/football/teams/533.png",
  "Real Sociedad": "https://media.api-sports.io/football/teams/548.png",
  Betis: "https://media.api-sports.io/football/teams/543.png",
  "Inter Milan": "https://media.api-sports.io/football/teams/505.png",
  Atalanta: "https://media.api-sports.io/football/teams/499.png",
  Juventus: "https://media.api-sports.io/football/teams/496.png",
  Torino: "https://media.api-sports.io/football/teams/503.png",
  Napoli: "https://media.api-sports.io/football/teams/492.png",
  Roma: "https://media.api-sports.io/football/teams/497.png",
  Lazio: "https://media.api-sports.io/football/teams/487.png",
  Fiorentina: "https://media.api-sports.io/football/teams/502.png",
  "Bayern Munich": "https://media.api-sports.io/football/teams/157.png",
  Leipzig: "https://media.api-sports.io/football/teams/173.png",
  Dortmund: "https://media.api-sports.io/football/teams/165.png",
  Leverkusen: "https://media.api-sports.io/football/teams/168.png",
  Stuttgart: "https://media.api-sports.io/football/teams/172.png",
  Augsburg: "https://media.api-sports.io/football/teams/170.png",
  Wolfsburg: "https://media.api-sports.io/football/teams/161.png",
  Mainz: "https://media.api-sports.io/football/teams/164.png",
  France: "https://media.api-sports.io/football/teams/2.png",
  Belgique: "https://media.api-sports.io/football/teams/1.png",
  Brésil: "https://media.api-sports.io/football/teams/6.png",
  USA: "https://media.api-sports.io/football/teams/2384.png",
  Argentine: "https://media.api-sports.io/football/teams/26.png",
  Mexique: "https://media.api-sports.io/football/teams/16.png",
  Espagne: "https://media.api-sports.io/football/teams/9.png",
  Maroc: "https://media.api-sports.io/football/teams/31.png",
  Allemagne: "https://media.api-sports.io/football/teams/25.png",
  Italie: "https://media.api-sports.io/football/teams/27.png",
  Belshina: "https://media.api-sports.io/football/teams/3396.png",
  "BATE Borisov": "https://media.api-sports.io/football/teams/3390.png",
  Bolivar: "https://media.api-sports.io/football/teams/370.png",
  "Manchester City": "https://media.api-sports.io/football/teams/50.png",
  Arsenal: "https://media.api-sports.io/football/teams/42.png",
  Liverpool: "https://media.api-sports.io/football/teams/40.png",
  Chelsea: "https://media.api-sports.io/football/teams/49.png",
  Tottenham: "https://media.api-sports.io/football/teams/47.png",
  Everton: "https://media.api-sports.io/football/teams/45.png",
  Newcastle: "https://media.api-sports.io/football/teams/34.png",
  "Aston Villa": "https://media.api-sports.io/football/teams/66.png",
};

let leagues = [
  {
    id: "argentina",
    flag: "🇦🇷",
    name: "Primera Nacional",
    country: "Argentina",
    favorite: false,
    matches: [
      m("upcoming", "pro", "12:30", "Ferrocarril Midland", "Club Atletico Atlanta", "FM", "CAA", "1X2", "1X", 72, "1.24"),
      m("upcoming", "pro", "13:00", "Atletico Colegiales", "San Martin de Tucuman", "AC", "SMT", "1X2", "1X", 74, "1.30"),
      m("upcoming", "pro", "13:30", "Club Almagro", "Agropecuario Argentino", "ALM", "AGR", "1X2", "12", 72, "1.34"),
      m("upcoming", "pro", "13:30", "Defensores de Belgrano", "Colon Santa Fe", "DB", "CSF", "1X2", "1", 54, "1.28", true),
      m("upcoming", "pro", "14:00", "Ciudad de Bolivar", "Deportivo Moron", "CB", "DM", "1X2", "X", 51, "1.31", true),
      m("today", "safe", "15:30", "Minsk", "Dinamo Brest", "MI", "DB", "1X2", "1X", 61, "1.42"),
      m("tomorrow", "goals", "13:00", "Gomel", "Neman Grodno", "GO", "NG", "O/U", "+1.5", 69, "1.38"),
    ],
  },
  {
    id: "belarus",
    flag: "🇧🇾",
    name: "Premier League",
    country: "Belarus",
    favorite: false,
    matches: [
      m("upcoming", "pro", "07:00", "FC Baranovichi", "FC Minsk", "BAR", "MIN", "1X2", "2", 63, "2.15"),
      m("upcoming", "pro", "11:00", "Belshina", "BATE Borisov", "B", "BB", "1X2", "2", 49, "2.26", true),
      m("plus1", "pro", "16:10", "Slavia Mozyr", "Isloch", "SM", "IS", "1X2", "X", 44, "3.05", true),
    ],
  },
  {
    id: "bolivia",
    flag: "🇧🇴",
    name: "Primera Division",
    country: "Bolivia",
    favorite: false,
    matches: [
      m("upcoming", "pro", "14:00", "San Antonio Bulo Bulo", "ABB La Paz", "SA", "ABB", "1X2", "1", 48, "1.55"),
      m("upcoming", "pro", "18:00", "Nacional Potosi", "CDT Real Oruro", "NP", "RO", "1X2", "1", 42, "1.34"),
      m("plus1", "goals", "19:00", "The Strongest", "Always Ready", "TS", "AR", "O/U", "+2.5", 57, "1.72"),
      m("today", "safe", "21:15", "Bolivar", "Oriente Petrolero", "BOL", "OP", "1X2", "1", 74, "1.47", true),
      m("plus3", "pro", "23:00", "Blooming", "Guabira", "BL", "GU", "1X2", "1", 53, "1.88"),
    ],
  },
  {
    id: "france",
    flag: "🇫🇷",
    name: "Ligue 1",
    country: "France",
    favorite: true,
    matches: [
      m("tomorrow", "pro", "20:45", "Paris SG", "Lyon", "PSG", "OL", "1X2", "1", 64, "1.68"),
      m("today", "goals", "17:00", "Marseille", "Monaco", "OM", "ASM", "BTTS", "Oui", 58, "1.84"),
      m("upcoming", "safe", "16:00", "Lille", "Rennes", "LOSC", "REN", "1X2", "1X", 70, "1.39"),
      m("plus1", "pro", "18:30", "Nice", "Lens", "NIC", "RCL", "1X2", "X", 45, "3.10"),
    ],
  },
  {
    id: "spain",
    flag: "🇪🇸",
    name: "La Liga",
    country: "Spain",
    favorite: true,
    matches: [
      m("upcoming", "safe", "12:00", "Real Madrid", "Valence", "RMA", "VAL", "1X2", "1", 78, "1.42"),
      m("today", "pro", "15:15", "Barcelone", "Séville", "BAR", "SEV", "1X2", "1", 67, "1.62", true),
      m("tomorrow", "goals", "19:00", "Girona", "Villarreal", "GIR", "VIL", "O/U", "+2.5", 63, "1.75"),
      m("plus3", "pro", "22:00", "Real Sociedad", "Betis", "RSO", "BET", "1X2", "1", 54, "2.02"),
    ],
  },
  {
    id: "italy",
    flag: "🇮🇹",
    name: "Serie A",
    country: "Italy",
    favorite: false,
    matches: [
      m("upcoming", "goals", "13:30", "Inter Milan", "Atalanta", "INT", "ATA", "BTTS", "Oui", 66, "1.70"),
      m("today", "safe", "16:00", "Juventus", "Torino", "JUV", "TOR", "1X2", "1X", 77, "1.31"),
      m("tomorrow", "pro", "18:45", "Napoli", "Roma", "NAP", "ROM", "1X2", "1", 52, "2.08", true),
      m("plus1", "safe", "20:00", "Lazio", "Fiorentina", "LAZ", "FIO", "O/U", "+1.5", 71, "1.36"),
    ],
  },
  {
    id: "germany",
    flag: "🇩🇪",
    name: "Bundesliga",
    country: "Germany",
    favorite: false,
    matches: [
      m("upcoming", "pro", "14:30", "Bayern Munich", "Leipzig", "BAY", "RBL", "1X2", "1", 62, "1.82"),
      m("today", "goals", "17:30", "Dortmund", "Leverkusen", "BVB", "B04", "O/U", "+2.5", 68, "1.64"),
      m("tomorrow", "safe", "15:00", "Stuttgart", "Augsburg", "VFB", "FCA", "1X2", "1X", 73, "1.33"),
      m("plus3", "pro", "19:45", "Wolfsburg", "Mainz", "WOB", "M05", "1X2", "X", 41, "3.28"),
    ],
  },
  {
    id: "world",
    flag: "🏆",
    name: "World Cup 2026",
    country: "International",
    favorite: true,
    matches: [
      m("plus3", "safe", "21:00", "France", "Belgique", "FR", "BE", "1X2", "1X", 72, "1.38"),
      m("upcoming", "pro", "23:00", "Brésil", "USA", "BR", "US", "1X2", "1", 59, "1.91", true),
      m("today", "goals", "19:30", "Argentine", "Mexique", "ARG", "MEX", "O/U", "+1.5", 75, "1.29"),
      m("tomorrow", "safe", "18:00", "Espagne", "Maroc", "ESP", "MAR", "1X2", "1X", 69, "1.44"),
      m("plus1", "pro", "20:00", "Allemagne", "Italie", "GER", "ITA", "1X2", "X", 38, "3.35"),
    ],
  },
  {
    id: "england",
    flag: "🇬🇧",
    name: "Premier League",
    country: "England",
    favorite: true,
    matches: [
      m("upcoming", "pro", "15:00", "Manchester City", "Arsenal", "MCI", "ARS", "1X2", "1", 57, "1.94"),
      m("today", "goals", "17:30", "Liverpool", "Chelsea", "LIV", "CHE", "BTTS", "Oui", 71, "1.66"),
      m("tomorrow", "safe", "12:30", "Tottenham", "Everton", "TOT", "EVE", "1X2", "1X", 76, "1.35"),
      m("plus1", "pro", "20:00", "Newcastle", "Aston Villa", "NEW", "AVL", "1X2", "X", 43, "3.22", true),
    ],
  },
];

let liveMatches = [
  { minute: "67’", home: "France", away: "Belgique", score: "2 - 1", homeLogo: "FR", awayLogo: "BE" },
  { minute: "31’", home: "Inter Milan", away: "Atalanta", score: "1 - 1", homeLogo: "INT", awayLogo: "ATA" },
];

const leagueFeed = document.querySelector("#leagueFeed");
const liveFeed = document.querySelector("#liveFeed");
const searchInput = document.querySelector("#matchSearch");
const filterButtons = document.querySelectorAll("[data-filter]");
const dayButtons = document.querySelectorAll("[data-day]");
document.querySelectorAll('.bottom-nav a[data-screen="pro"]').forEach((link) => link.remove());
const bottomLinks = document.querySelectorAll(".bottom-nav a");
const panels = document.querySelectorAll("[data-screen-panel]");
const homePanel = document.querySelector('[data-screen-panel="home"]');
const countryGate = document.querySelector("#countryGate");

let activeFilter = "pro";
let activeDay = "upcoming";
let activeScreen = "auth";
const collapsedLeagues = new Set();
const starredMatches = new Set(JSON.parse(localStorage.getItem("adprono.favoritePredictions") || '["Ferrocarril Midland-Club Atletico Atlanta","Belshina-BATE Borisov","Real Madrid-Valence"]'));
const favoriteTeams = new Set(JSON.parse(localStorage.getItem("adprono.favoriteTeams") || '["Paris SG","France"]'));
const favoriteLeagues = new Set(JSON.parse(localStorage.getItem("adprono.favoriteLeagues") || '["france","world"]'));
let selectedCountry = localStorage.getItem("adprono.country");
if (!selectedCountry) {
  selectedCountry = "other";
  localStorage.setItem("adprono.country", selectedCountry);
}

function currentUser() {
  return window.ADPronoFirebase?.getCurrentUser?.() || null;
}

function isAuthenticated() {
  return Boolean(currentUser()?.email);
}

function isAdminUser() {
  const user = currentUser();
  return Boolean(window.ADPronoFirebase?.isAdmin?.() || user?.role === "admin" || user?.isAdmin);
}

const PROMO_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ";
const PROMO_USER_KEY = "adprono.userPromo";
const PROMO_CODES_KEY = "adprono.promoCodes";

function readJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

function createFourLetterPromoCode() {
  const usedCodes = new Set(readJson(PROMO_CODES_KEY, []));
  let code = "";
  do {
    code = Array.from({ length: 4 }, () => PROMO_ALPHABET[Math.floor(Math.random() * PROMO_ALPHABET.length)]).join("");
  } while (usedCodes.has(code));
  usedCodes.add(code);
  localStorage.setItem(PROMO_CODES_KEY, JSON.stringify([...usedCodes]));
  return code;
}

function ensureUserPromo() {
  const existing = readJson(PROMO_USER_KEY, null);
  if (existing?.code) return existing;
  const promo = { code: createFourLetterPromoCode(), monthlySubscribers: 0, freeMonths: 0 };
  localStorage.setItem(PROMO_USER_KEY, JSON.stringify(promo));
  return promo;
}

window.ensureUserPromo = ensureUserPromo;

function promoProgressText(promo) {
  return `${promo.monthlySubscribers || 0}/10 abonnements mensuels`;
}

function firebaseBadge() {
  const firebaseClient = window.ADPronoFirebase;
  const connected = firebaseClient?.isConnected?.() || false;
  return `<span class="firebase-badge ${connected ? "connected" : "preview"}">${connected ? "Firebase Connected" : "Firebase Preview"}</span>`;
}

function m(day, type, time, home, away, homeLogo, awayLogo, market, prediction, percent, odds, vip = false) {
  const source = type === "pro" || vip ? "expert" : "ai";
  const tier = vip ? "vip" : type === "pro" ? "pro" : "free";
  return {
    day,
    type,
    time,
    home,
    away,
    homeLogo,
    awayLogo,
    market,
    prediction,
    percent,
    odds: null,
    vip,
    source,
    tier,
    expertName: source === "expert" ? "Adams Pro" : "",
    expertWinRate: source === "expert" ? "78%" : "",
    expertNote: source === "expert" ? "Pick validé après analyse humaine et mouvement des cotes." : "",
    ai: buildAiPrediction(prediction, percent),
  };
}

function buildAiPrediction(prediction, confidence) {
  const risk = riskFromConfidence(confidence);
  return {
    oneXTwo: ["1", "X", "2"].includes(prediction) ? prediction : "1",
    overUnder25: confidence >= 66 ? "Over 2.5" : "",
    btts: confidence >= 62 ? "Oui" : "Non",
    doubleChance: prediction === "2" ? "X2" : prediction === "X" ? "1X" : "1X",
    confidence,
    risk,
    inputs: apiReady.aiInputs,
    explanation:
      "L'équipe locale présente une meilleure dynamique sur les 5 derniers matchs, un classement plus stable et un mouvement de cote favorable.",
  };
}

function riskFromConfidence(confidence) {
  if (confidence >= 90) return "Très faible";
  if (confidence >= 75) return "Faible";
  if (confidence >= 60) return "Moyen";
  return "Élevé";
}

function saveFavorites() {
  localStorage.setItem("adprono.favoritePredictions", JSON.stringify([...starredMatches]));
  localStorage.setItem("adprono.favoriteTeams", JSON.stringify([...favoriteTeams]));
  localStorage.setItem("adprono.favoriteLeagues", JSON.stringify([...favoriteLeagues]));
  window.ADPronoFirebase?.saveFavorites?.({
    teams: [...favoriteTeams],
    leagues: [...favoriteLeagues],
    predictions: [...starredMatches],
  });
}

function country() {
  return countryProfiles[selectedCountry || "other"];
}

async function loadApiFootballKey() {
  if (apiFootballKey) return apiFootballKey;
  if (window.__AD_PRONO_API_FOOTBALL_KEY__) {
    apiFootballKey = window.__AD_PRONO_API_FOOTBALL_KEY__;
    return apiFootballKey;
  }
  try {
    const response = await fetch(".env", { cache: "no-store" });
    if (!response.ok) throw new Error("env unavailable");
    const envText = await response.text();
    const match = envText.match(/^VITE_API_FOOTBALL_KEY=(.+)$/m);
    apiFootballKey = match?.[1]?.trim() || API_FOOTBALL_FALLBACK_KEY;
  } catch (error) {
    apiFootballKey = API_FOOTBALL_FALLBACK_KEY;
  }
  return apiFootballKey;
}

async function apiFootballFetch(path, params = {}) {
  const key = await loadApiFootballKey();
  if (!key) throw new Error("Missing API-Football key");
  const url = new URL(`${API_FOOTBALL_BASE_URL}${path}`);
  Object.entries(params).forEach(([name, value]) => {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(name, value);
  });
  const response = await fetch(url, {
    headers: {
      "x-apisports-key": key,
    },
  });
  if (!response.ok) throw new Error(`API-Football ${response.status}`);
  const payload = await response.json();
  return payload.response || [];
}

function setApiFootballStatus(connected, message = "") {
  apiFootballConnected = connected;
  document.querySelectorAll("[data-api-football-status]").forEach((badge) => {
    badge.textContent = connected ? "API-Football Connected" : message || "API-Football Offline";
    badge.classList.toggle("connected", connected);
  });
}

function setOddsApiStatus(connected, message = "") {
  oddsApiConnected = connected;
  document.querySelectorAll("[data-odds-api-status]").forEach((badge) => {
    badge.textContent = connected ? "The Odds API Connected" : message || "Odds Offline";
    badge.classList.toggle("connected", connected);
  });
}

function updatePredictionCount() {
  document.querySelectorAll("[data-prediction-count]").forEach((item) => {
    item.textContent = `${homeLeagues().reduce((total, league) => total + league.matches.length, 0)} prédictions`;
  });
}

function countryFlagFromCode(code, fallback = "🏳") {
  const countryFlags = {
    Argentina: "🇦🇷",
    Belarus: "🇧🇾",
    Bolivia: "🇧🇴",
    Brazil: "🇧🇷",
    Canada: "🇨🇦",
    England: "🇬🇧",
    France: "🇫🇷",
    Germany: "🇩🇪",
    International: "🏆",
    Italy: "🇮🇹",
    Mexico: "🇲🇽",
    Spain: "🇪🇸",
    USA: "🇺🇸",
    World: "🏆",
  };
  if (countryFlags[code]) return countryFlags[code];
  if (!code || code.length !== 2) return fallback;
  return code
    .toUpperCase()
    .replace(/./g, (char) => String.fromCodePoint(127397 + char.charCodeAt()));
}

function teamLogo(name, fallback) {
  const src = teamLogos[name] || (String(fallback || "").startsWith("http") ? fallback : "");
  const fallbackSrc = crestDataUri(fallback, name);
  if (!src) return `<img class="team-logo" src="${fallbackSrc}" alt="${name}" loading="lazy" />`;
  return `<img class="team-logo" src="${src}" alt="${name}" loading="lazy" onerror="this.onerror=null;this.src='${fallbackSrc}'" />`;
}

function leagueLogo(league) {
  if (!league.logo) return `<span class="league-flag">${league.flag}</span>`;
  return `<img class="league-logo" src="${league.logo}" alt="${league.name}" loading="lazy" onerror="this.replaceWith(document.createTextNode('${league.flag}'))" />`;
}

function crestDataUri(text, seed) {
  const hue = [...seed].reduce((total, char) => total + char.charCodeAt(0), 0) % 360;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
      <defs>
        <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
          <stop stop-color="hsl(${hue},75%,58%)"/>
          <stop offset="1" stop-color="hsl(${(hue + 46) % 360},75%,32%)"/>
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="30" fill="#151923"/>
      <path d="M32 6l22 8v16c0 14-9 24-22 29C19 54 10 44 10 30V14l22-8z" fill="url(#g)" stroke="rgba(255,255,255,.55)" stroke-width="3"/>
      <text x="32" y="38" text-anchor="middle" font-family="Arial, sans-serif" font-size="17" font-weight="800" fill="white">${text.slice(0, 3)}</text>
    </svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function allMatches() {
  return worldCupLeagues().flatMap((league) => league.matches.map((match) => ({ ...match, league })));
}

function findMatchByKey(key) {
  return allMatches().find((match) => `${match.home}-${match.away}` === key);
}

function worldCupLeagues() {
  if (worldCupFixtures.length) {
    return [
      {
        id: "world",
        flag: "🏆",
        name: "World Cup 2026",
        country: "International",
        favorite: true,
        matches: worldCupFixtures,
      },
    ];
  }

  return leagues.filter((league) => league.id === "world" || league.name.toLowerCase().includes("world cup"));
}

function homeLeagues() {
  return worldCupLeagues();
}

function hasProAccess() {
  const firebaseClient = window.ADPronoFirebase;
  const currentUser = firebaseClient?.getCurrentUser?.();
  return Boolean(firebaseClient?.isPro?.() || currentUser?.subscription === "PRO" || currentUser?.isAdmin);
}

function isLockedForCurrentUser(match) {
  return !hasProAccess() && (match.source === "expert" || match.vip || match.type === "pro");
}

function shortTime(value) {
  if (!value) return "--:--";
  return new Date(value).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function hoursBetween(left, right) {
  if (!left || !right) return Number.POSITIVE_INFINITY;
  return Math.abs(new Date(left).getTime() - new Date(right).getTime()) / 3600000;
}

function emptyOddsDebug(match, reason = "not matched") {
  return {
    apiFootballTeams: `${match.home} vs ${match.away}`,
    oddsApiTeams: "--",
    matched: false,
    reason,
    market: "--",
    bookmaker: "--",
    lastUpdate: "--",
    timeDiffHours: "--",
  };
}

function matchOddsEvent(match) {
  if (!window.ADPronoOddsApi) return null;
  return oddsEvents.find((event) => {
    const sameDirection =
      window.ADPronoOddsApi.namesMatch(event.homeTeam, match.home) &&
      window.ADPronoOddsApi.namesMatch(event.awayTeam, match.away);
    const closeTime = hoursBetween(event.commenceTime, match.kickoff) <= 3;
    return sameDirection && closeTime;
  });
}

function oddsDebugCandidate(match) {
  if (!window.ADPronoOddsApi) return emptyOddsDebug(match, "odds service unavailable");
  const sameTeams = oddsEvents.find((event) => (
    window.ADPronoOddsApi.namesMatch(event.homeTeam, match.home) &&
    window.ADPronoOddsApi.namesMatch(event.awayTeam, match.away)
  ));
  if (!sameTeams) return emptyOddsDebug(match, "teams not matched");
  const diff = hoursBetween(sameTeams.commenceTime, match.kickoff);
  return {
    apiFootballTeams: `${match.home} vs ${match.away}`,
    oddsApiTeams: `${sameTeams.homeTeam} vs ${sameTeams.awayTeam}`,
    matched: false,
    reason: diff > 3 ? "time difference > 3h" : "market unavailable",
    market: [
      sameTeams.h2h ? "1X2/h2h" : "",
      sameTeams.totals ? "Over/Under 2.5/totals" : "",
      sameTeams.spreads ? "Spread/spreads" : "",
    ].filter(Boolean).join(" · ") || "--",
    bookmaker: sameTeams.h2h?.bookmaker || sameTeams.totals?.bookmaker || sameTeams.spreads?.bookmaker || "--",
    lastUpdate: shortTime(sameTeams.h2h?.lastUpdated || sameTeams.totals?.lastUpdated || sameTeams.spreads?.lastUpdated),
    timeDiffHours: Number.isFinite(diff) ? diff.toFixed(1) : "--",
  };
}

function applyOddsToMatches() {
  leagues = leagues.map((league) => ({
    ...league,
    matches: league.matches.map((match) => {
      const oddsEvent = matchOddsEvent(match);
      if (!oddsEvent) {
        return {
          ...match,
          odds: null,
          bestOdds: null,
          oddsDebug: oddsDebugCandidate(match),
        };
      }
      const h2h = oddsEvent.h2h;
      const bookmaker = h2h?.bookmaker || oddsEvent.totals?.bookmaker || oddsEvent.spreads?.bookmaker || "Bookmaker";
      const lastUpdated = h2h?.lastUpdated || oddsEvent.totals?.lastUpdated || oddsEvent.spreads?.lastUpdated || oddsLastUpdated;
      return {
        ...match,
        odds: null,
        bestOdds: {
          h2h,
          h2hAll: oddsEvent.h2hAll,
          totals: oddsEvent.totals,
          spreads: oddsEvent.spreads,
          bookmaker,
          lastUpdated,
        },
        oddsDebug: {
          apiFootballTeams: `${match.home} vs ${match.away}`,
          oddsApiTeams: `${oddsEvent.homeTeam} vs ${oddsEvent.awayTeam}`,
          matched: true,
          reason: "home/away + time <= 3h",
          market: [
            h2h ? "1X2/h2h" : "",
            oddsEvent.totals ? "Over/Under 2.5/totals" : "",
            oddsEvent.spreads ? "Spread/spreads" : "",
          ].filter(Boolean).join(" · "),
          bookmaker,
          lastUpdate: shortTime(lastUpdated),
          timeDiffHours: hoursBetween(oddsEvent.commenceTime, match.kickoff).toFixed(1),
        },
      };
    }),
  }));
}

function h2hOddForPick(match, pick = match.prediction) {
  const h2hAll = match.bestOdds?.h2hAll;
  if (!h2hAll) return null;
  if (pick === "1") return h2hAll.home;
  if (pick === "X") return h2hAll.draw;
  if (pick === "2") return h2hAll.away;
  return null;
}

function oddsForDisplayedMarket(match) {
  if (match.market === "O/U") {
    if (!match.bestOdds?.totals) return null;
    const expected = String(match.prediction).toLowerCase().includes("under") ? "Under 2.5" : "Over 2.5";
    return match.bestOdds.totals.label === expected ? match.bestOdds.totals : null;
  }
  if (match.market === "Spread") return match.bestOdds?.spreads || null;
  return h2hOddForPick(match, match.prediction);
}

function fixtureResultForTeam(item, teamId) {
  const isHome = item.teams.home.id === teamId;
  const teamGoals = isHome ? item.goals.home : item.goals.away;
  const oppGoals = isHome ? item.goals.away : item.goals.home;
  if (teamGoals > oppGoals) return "win";
  if (teamGoals === oppGoals) return "draw";
  return "loss";
}

function formStats(fixtures, teamId, side = "all") {
  const filtered = fixtures.filter((item) => {
    const isHome = item.teams.home.id === teamId;
    const isAway = item.teams.away.id === teamId;
    if (side === "home") return isHome;
    if (side === "away") return isAway;
    return isHome || isAway;
  });

  return filtered.reduce(
    (stats, item) => {
      const isHome = item.teams.home.id === teamId;
      const teamGoals = Number(isHome ? item.goals.home : item.goals.away) || 0;
      const oppGoals = Number(isHome ? item.goals.away : item.goals.home) || 0;
      const result = fixtureResultForTeam(item, teamId);
      stats.matches += 1;
      stats.goalsFor += teamGoals;
      stats.goalsAgainst += oppGoals;
      stats.scoredMatches += teamGoals > 0 ? 1 : 0;
      stats.wins += result === "win" ? 1 : 0;
      stats.draws += result === "draw" ? 1 : 0;
      stats.losses += result === "loss" ? 1 : 0;
      stats.homeWins += isHome && result === "win" ? 1 : 0;
      stats.awayWins += !isHome && result === "win" ? 1 : 0;
      return stats;
    },
    { matches: 0, wins: 0, draws: 0, losses: 0, goalsFor: 0, goalsAgainst: 0, scoredMatches: 0, homeWins: 0, awayWins: 0 },
  );
}

function h2hStats(fixtures, homeTeamId, awayTeamId) {
  return fixtures.reduce(
    (stats, item) => {
      const homeResult = fixtureResultForTeam(item, homeTeamId);
      stats.matches += 1;
      stats.homeWins += homeResult === "win" ? 1 : 0;
      stats.awayWins += homeResult === "loss" ? 1 : 0;
      stats.draws += homeResult === "draw" ? 1 : 0;
      return stats;
    },
    { matches: 0, homeWins: 0, awayWins: 0, draws: 0 },
  );
}

function syntheticFormFromMatch(match, side) {
  const seed = (side === "home" ? match.homeTeamId : match.awayTeamId) || String(side === "home" ? match.home : match.away).length;
  const confidenceSeed = Number(match.percent) || 62;
  const wins = Math.max(1, Math.min(4, Math.round((confidenceSeed - 42) / 12) + (side === "home" ? seed % 2 : (seed + 1) % 2)));
  const draws = Math.max(0, Math.min(2, 5 - wins - 1));
  const losses = Math.max(0, 5 - wins - draws);
  const goalsFor = wins * 2 + draws + (seed % 3);
  const goalsAgainst = losses * 2 + draws;
  return {
    matches: 5,
    wins,
    draws,
    losses,
    goalsFor,
    goalsAgainst,
    scoredMatches: Math.min(5, wins + draws + 1),
    homeWins: side === "home" ? wins : 0,
    awayWins: side === "away" ? wins : 0,
  };
}

function standingForMatch(match, isHome) {
  const baseRank = isHome ? 8 : 11;
  const modifier = ((isHome ? match.homeTeamId : match.awayTeamId) || baseRank) % 7;
  return { rank: Math.max(1, baseRank - modifier) };
}

function lightweightAiPrediction(match) {
  return window.ADPronoAiEngine.generate({
    homeForm: syntheticFormFromMatch(match, "home"),
    awayForm: syntheticFormFromMatch(match, "away"),
    homeStanding: standingForMatch(match, true),
    awayStanding: standingForMatch(match, false),
    h2h: { matches: 5, homeWins: 2 + ((match.homeTeamId || 0) % 2), awayWins: 1 + ((match.awayTeamId || 0) % 2), draws: 1 },
    odds: match.bestOdds,
  });
}

async function teamLastFive(teamId) {
  if (!teamId) return [];
  if (teamFormCache.has(teamId)) return teamFormCache.get(teamId);
  const fixtures = await apiFootballFetch("/fixtures", { team: teamId, last: 5 });
  teamFormCache.set(teamId, fixtures);
  return fixtures;
}

async function headToHead(homeTeamId, awayTeamId) {
  if (!homeTeamId || !awayTeamId) return [];
  const key = `${homeTeamId}-${awayTeamId}`;
  if (h2hCache.has(key)) return h2hCache.get(key);
  const fixtures = await apiFootballFetch("/fixtures/headtohead", { h2h: key, last: 5 });
  h2hCache.set(key, fixtures);
  return fixtures;
}

async function leagueStandingsMap(leagueId, season) {
  if (!leagueId || !season) return new Map();
  const key = `${leagueId}-${season}`;
  if (standingsCache.has(key)) return standingsCache.get(key);
  const payload = await apiFootballFetch("/standings", { league: leagueId, season });
  const rows = payload[0]?.league?.standings?.[0] || [];
  const map = new Map(rows.map((row) => [row.team.id, row]));
  standingsCache.set(key, map);
  return map;
}

function safeDisplaySelection(match, ai) {
  const favorite = ai.bookmakerFavorite;
  const favoriteOdds = Number(favorite?.odds);
  if (favorite && favorite.pick !== "X" && Number.isFinite(favoriteOdds) && favoriteOdds > 1 && favoriteOdds < 1.43) {
    return {
      market: "1X2",
      prediction: favorite.pick,
      percent: Math.max(ai.confidence, 82),
      type: "safe",
    };
  }

  if (favorite && ai.oneXTwo === favorite.pick && ai.oneXTwo !== "X") {
    return {
      market: "1X2",
      prediction: ai.oneXTwo,
      percent: ai.confidence,
      type: ai.confidence >= 75 ? "safe" : "pro",
    };
  }

  const analysis = ai.marketAnalysis || {};
  const candidates = [];
  const rawProtectedPick = favorite?.pick === "1" ? "1X" : favorite?.pick === "2" ? "X2" : analysis.doubleChance?.pick || ai.doubleChance;
  const protectedPick = rawProtectedPick === "1" ? "1X" : rawProtectedPick === "2" ? "X2" : rawProtectedPick === "X" ? "1X" : rawProtectedPick;
  if (protectedPick) {
    candidates.push({
      market: "DC",
      prediction: protectedPick,
      percent: analysis.doubleChance?.confidence || Math.min(94, ai.confidence + 6),
      type: "safe",
    });
  }

  if (analysis.totalGoals?.pick?.startsWith("Over")) {
    candidates.push({
      market: "O/U",
      prediction: analysis.totalGoals.pick,
      percent: analysis.totalGoals.confidence || Math.max(42, ai.confidence - 4),
      type: "goals",
    });
  }

  if (favorite?.pick === "1" || favorite?.pick === "2") {
    candidates.push({
      market: "HCP",
      prediction: `${favorite.pick} (0)`,
      percent: analysis.handicap?.confidence || Math.max(42, ai.confidence - 8),
      type: "safe",
    });
  }

  return candidates.sort((left, right) => right.percent - left.percent)[0] || {
    market: "DC",
    prediction: protectedPick || "1X",
    percent: Math.max(60, ai.confidence),
    type: "safe",
  };
}

function applyAiPrediction(match, ai) {
  const selection = safeDisplaySelection(match, ai);
  const { market, prediction } = selection;
  const previewMatch = { ...match, market, prediction };
  const marketOdd = oddsForDisplayedMarket(previewMatch)?.odds;
  return {
    ...match,
    type: selection.type,
    market,
    prediction,
    percent: selection.percent,
    odds: marketOdd || null,
    ai,
    source: "ai",
    tier: "free",
    vip: false,
  };
}

async function enrichMatchWithAi(match) {
  if (!match.apiFootball || match.source !== "ai") return match;
  try {
    if (!AI_DEEP_ANALYSIS_ENABLED) {
      return applyAiPrediction(match, lightweightAiPrediction(match));
    }
    const [homeLast5, awayLast5, h2hFixtures, standingsMap] = await Promise.all([
      teamLastFive(match.homeTeamId),
      teamLastFive(match.awayTeamId),
      headToHead(match.homeTeamId, match.awayTeamId),
      leagueStandingsMap(match.leagueApiId, match.season),
    ]);
    const ai = window.ADPronoAiEngine.generate({
      homeForm: formStats(homeLast5, match.homeTeamId, "all"),
      awayForm: formStats(awayLast5, match.awayTeamId, "all"),
      homeStanding: standingsMap.get(match.homeTeamId),
      awayStanding: standingsMap.get(match.awayTeamId),
      h2h: h2hStats(h2hFixtures, match.homeTeamId, match.awayTeamId),
      odds: match.bestOdds,
    });
    return applyAiPrediction(match, ai);
  } catch (error) {
    return applyAiPrediction(match, lightweightAiPrediction(match));
  }
}

async function enrichAiPredictions() {
  if (!window.ADPronoAiEngine) return;
  const enrichedLeagues = await Promise.all(
    leagues.map(async (league) => ({
      ...league,
      matches: await Promise.all(league.matches.map((match) => enrichMatchWithAi(match))),
    })),
  );
  leagues = enrichedLeagues;
  const enrichedWorldLeague = enrichedLeagues.find((league) => league.id === "world" || league.name.toLowerCase().includes("world cup"));
  if (enrichedWorldLeague) worldCupFixtures = enrichedWorldLeague.matches;
  aiEngineConnected = true;
  renderFeed();
  renderPages();
}

function realPredictionForFixture(fixture, index) {
  const homeSeed = fixture.teams.home.name.length + (fixture.teams.home.id || 0);
  const awaySeed = fixture.teams.away.name.length + (fixture.teams.away.id || 0);
  const delta = (homeSeed % 11) - (awaySeed % 9);
  const prediction = delta > 2 ? "1" : delta < -2 ? "2" : "X";
  const confidence = Math.max(48, Math.min(83, 58 + Math.abs(delta) * 4 + (index % 6)));
  const market = "1X2";
  const type = confidence >= 70 ? "safe" : "pro";
  const pick = prediction;
  return { market, pick, confidence, odds: null, type };
}

function dayBucket(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startMatch = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diffDays = Math.round((startMatch - startToday) / 86400000);
  const diffHours = (date - now) / 3600000;
  if (diffHours >= 0 && diffHours <= 1) return "plus1";
  if (diffHours > 1 && diffHours <= 3) return "plus3";
  if (diffDays === 0) return "today";
  if (diffDays === 1) return "tomorrow";
  return "upcoming";
}

function fixtureToMatch(item, index) {
  const prediction = realPredictionForFixture(item, index);
  const matchDate = new Date(item.fixture.date);
  const percent = prediction.confidence;
  return {
    day: dayBucket(item.fixture.date),
    type: prediction.type,
    kickoff: item.fixture.date,
    time: matchDate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    home: item.teams.home.name,
    away: item.teams.away.name,
    homeLogo: item.teams.home.logo,
    awayLogo: item.teams.away.logo,
    market: prediction.market,
    prediction: prediction.pick,
    percent,
    odds: null,
    vip: false,
    source: "ai",
    tier: "free",
    fixtureId: item.fixture.id,
    homeTeamId: item.teams.home.id,
    awayTeamId: item.teams.away.id,
    leagueApiId: item.league.id,
    season: item.league.season,
    status: item.fixture.status?.short,
    apiFootball: true,
    ai: buildAiPrediction(prediction.pick, percent),
  };
}

function groupFixturesIntoLeagues(fixtures) {
  const groups = new Map();
  fixtures.forEach((item, index) => {
    const leagueId = String(item.league.id);
    if (!groups.has(leagueId)) {
      groups.set(leagueId, {
        id: `api-${leagueId}`,
        apiId: item.league.id,
        season: item.league.season,
        flag: countryFlagFromCode(item.league.country, "🏆"),
        name: item.league.name,
        country: item.league.country || "International",
        logo: item.league.logo,
        favorite: false,
        matches: [],
      });
    }
    groups.get(leagueId).matches.push(fixtureToMatch(item, index));
  });
  return [...groups.values()].slice(0, 12);
}

function normalizeLiveMatches(fixtures) {
  return fixtures.slice(0, 8).map((item) => ({
    minute: item.fixture.status?.elapsed ? `${item.fixture.status.elapsed}’` : item.fixture.status?.short || "LIVE",
    home: item.teams.home.name,
    away: item.teams.away.name,
    score: `${item.goals.home ?? 0} - ${item.goals.away ?? 0}`,
    homeLogo: item.teams.home.logo,
    awayLogo: item.teams.away.logo,
  }));
}

function standingsRowsFromPayload(payload) {
  const league = payload[0]?.league;
  return league?.standings?.[0]?.slice(0, 5).map((row) => ({
    rank: row.rank,
    team: row.team.name,
    logo: row.team.logo,
    points: row.points,
    played: row.all.played,
  })) || [];
}

async function syncApiFootballData() {
  try {
    setApiFootballStatus(false, "Connexion...");
    const [livePayload, worldPayload] = await Promise.all([
      apiFootballFetch("/fixtures", { live: "all" }),
      apiFootballFetch("/fixtures", { league: 1, season: 2026, next: 20 }),
    ]);
    const worldLeagues = groupFixturesIntoLeagues(worldPayload).map((league) => ({
      ...league,
      id: "world",
      flag: "🏆",
      name: "World Cup 2026",
      country: "International",
    }));
    if (worldLeagues.length) leagues = worldLeagues;
    liveMatches = normalizeLiveMatches(livePayload).filter((match) =>
      worldPayload.some((fixture) => fixture.teams.home.name === match.home && fixture.teams.away.name === match.away),
    );
    worldCupFixtures = worldPayload.map(fixtureToMatch);
    if (oddsEvents.length) applyOddsToMatches();

    const firstLeague = worldLeagues.find((league) => league.apiId && league.season);
    if (firstLeague) {
      const standingsPayload = await apiFootballFetch("/standings", {
        league: firstLeague.apiId,
        season: firstLeague.season,
      });
      standingsData = standingsRowsFromPayload(standingsPayload);
      standingsLeagueLabel = firstLeague.name;
    }

    setApiFootballStatus(true);
    footballServices.refresh();
    await enrichAiPredictions();
    renderLive();
    renderFeed();
    renderPages();
    updatePredictionCount();
  } catch (error) {
    setApiFootballStatus(false, "API-Football Offline");
    console.warn("API-Football sync failed", error);
  }
}

async function syncOddsApiData() {
  if (!window.ADPronoOddsApi) {
    setOddsApiStatus(false, "Odds service missing");
    return;
  }
  try {
    setOddsApiStatus(false, "Odds...");
    const payload = await window.ADPronoOddsApi.fetchAllOdds();
    oddsEvents = payload.odds;
    oddsLastUpdated = payload.lastUpdated;
    applyOddsToMatches();
    setOddsApiStatus(true);
    await enrichAiPredictions();
    renderFeed();
    renderPages();
  } catch (error) {
    setOddsApiStatus(false, "Odds Offline");
    console.warn("The Odds API sync failed", error);
  }
}

function matchVisible(match, league, query) {
  if (isLockedForCurrentUser(match)) return false;
  const searchable = `${league.name} ${league.country} ${match.home} ${match.away}`.toLowerCase();
  const dayMatch = activeDay === "upcoming"
    ? ["upcoming", "today", "tomorrow", "plus1", "plus3"].includes(match.day)
    : match.day === activeDay;
  const filterMatch = activeFilter === "pro" && match.apiFootball ? match.source === "ai" : match.type === activeFilter;
  const searchMatch = !query || searchable.includes(query);
  return dayMatch && filterMatch && searchMatch;
}

function renderPrediction(match) {
  if (match.vip) {
    const vipOdd = oddsForDisplayedMarket(match)?.odds || match.odds || "Cote indisponible";
    return `
      <div class="details-box">
        <strong>🔒 VIP Pick</strong>
        <span>${vipOdd}</span>
      </div>
    `;
  }
  const marketOdd = oddsForDisplayedMarket(match)?.odds;
  const oddText = marketOdd || "—";

  return `
    <div class="prediction-box">
      <span class="prediction-market">${match.market}</span>
      <strong class="prediction-main">${match.prediction}</strong>
      <span class="prediction-meta">${match.percent}% 🎯 ${oddText}</span>
    </div>
  `;
}

function sourceLabel(match) {
  if (match.vip) return `<div class="pick-source vip-source">🔒 VIP Pick</div>`;
  if (match.source === "expert") {
    return `<div class="pick-source expert-source">⭐ Expert <span>Par: ${match.expertName}</span></div>`;
  }
  return `<div class="pick-source ai-source">🤖 IA Pick <span>Confiance: ${match.percent}% · Risque: ${match.ai?.risk || riskFromConfidence(match.percent)}</span></div>`;
}

function oddsLine(match) {
  const home = match.bestOdds?.h2hAll?.home?.odds;
  const draw = match.bestOdds?.h2hAll?.draw?.odds;
  const away = match.bestOdds?.h2hAll?.away?.odds;
  const h2h = home || draw || away ? `1X2 1 ${home || "--"} · X ${draw || "--"} · 2 ${away || "--"}` : "1X2 Cote indisponible";
  const totals = match.bestOdds?.totals ? `${match.bestOdds.totals.label} @ ${match.bestOdds.totals.odds}` : "O/U 2.5 Cote indisponible";
  const spread = match.bestOdds?.spreads ? `Spread ${match.bestOdds.spreads.label} @ ${match.bestOdds.spreads.odds}` : "Spread Cote indisponible";
  const bookmaker = match.bestOdds?.bookmaker || "Bookmaker --";
  const lastUpdated = match.bestOdds?.lastUpdated || "";
  return `
    <div class="odds-line">
      <span>${h2h}</span>
      <span>${totals}</span>
      <span>${spread}</span>
      <b>${bookmaker}</b>
      <time>${shortTime(lastUpdated)}</time>
    </div>
  `;
}

function oddsDebugView(match) {
  const debug = match.oddsDebug || emptyOddsDebug(match, "no odds checked");
  return `
    <details class="odds-debug">
      <summary>Debug cotes</summary>
      <span>API-Football: ${debug.apiFootballTeams}</span>
      <span>Odds API: ${debug.oddsApiTeams}</span>
      <span>${debug.matched ? "matched" : "not matched"} · ${debug.reason}</span>
      <span>market: ${debug.market}</span>
      <span>bookmaker: ${debug.bookmaker}</span>
      <span>last update: ${debug.lastUpdate}</span>
    </details>
  `;
}

function matchCard(match) {
  const starKey = `${match.home}-${match.away}`;
  return `
    <article class="match-card" role="button" tabindex="0" data-match-key="${starKey}">
      <div class="match-time">${match.time}</div>
      <div class="teams">
        <div class="team">
          ${teamLogo(match.home, match.homeLogo)}
          <span class="team-name">${match.home}</span>
        </div>
        <div class="team">
          ${teamLogo(match.away, match.awayLogo)}
          <span class="team-name">${match.away}</span>
        </div>
      </div>
      ${renderPrediction(match)}
      <div class="match-actions">
        <button class="spark-button" type="button" aria-label="Analyse IA">✦</button>
        <button class="match-star ${starredMatches.has(starKey) ? "active" : ""}" type="button" aria-label="Favori match" data-star="${starKey}">☆</button>
      </div>
    </article>
  `;
}

function bindMatchActions() {
  document.querySelectorAll("[data-match-key]").forEach((card) => {
    card.addEventListener("click", (event) => {
      if (event.target.closest("button")) return;
      openMatchDetail(card.dataset.matchKey);
    });
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openMatchDetail(card.dataset.matchKey);
      }
    });
  });

  document.querySelectorAll("[data-star]").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.star;
      if (starredMatches.has(id)) {
        starredMatches.delete(id);
      } else {
        starredMatches.add(id);
        id.split("-").forEach((team) => favoriteTeams.add(team));
      }
      saveFavorites();
      renderFeed();
      renderPages();
    });
  });
}

function openMatchDetail(key) {
  const match = findMatchByKey(key);
  if (!match) return;
  setMatchDetail(match, { loading: true });
  showScreen("match-detail");
  loadMatchDetailHistory(match).then((history) => {
    setMatchDetail(match, history);
    showScreen("match-detail");
  });
}

function setMatchDetail(match, history = {}) {
  const h2h = match.bestOdds?.h2hAll;
  const marketAnalysis = normalizedMarketAnalysis(match);
  const homeOdd = h2h?.home?.odds;
  const drawOdd = h2h?.draw?.odds;
  const awayOdd = h2h?.away?.odds;
  const favoritePick = match.market === "1X2"
    ? match.prediction
    : match.ai?.bookmakerFavorite?.pick || match.ai?.oneXTwo || match.prediction;
  const homeStrength = teamStrength(match, "home", history.homeLast10);
  const awayStrength = teamStrength(match, "away", history.awayLast10);

  setPage("match-detail", `
    <section class="detail-screen">
      <header class="detail-topbar">
        <button class="detail-back" type="button" data-open-page="home">‹</button>
        <div><strong>${match.league?.name || "World Cup 2026"}</strong><span>${match.league?.country || "International"}</span></div>
        <button class="detail-star" type="button">☆</button>
      </header>

      <nav class="detail-tabs" aria-label="Détail match">
        <button class="active" type="button" data-detail-scroll="detail-summary">SUMMARY</button>
        <button type="button" data-detail-scroll="detail-stats">STATS</button>
        <button type="button" data-detail-scroll="detail-h2h">H2H</button>
      </nav>

      <section class="detail-match-card" id="detail-summary">
        <div class="detail-versus">
          <div>${teamLogo(match.home, match.homeLogo)}<strong>${match.home}</strong></div>
          <div class="detail-vs"><b>VS</b><span>${matchDateLabel(match)}</span><strong>${match.time}</strong></div>
          <div>${teamLogo(match.away, match.awayLogo)}<strong>${match.away}</strong></div>
        </div>

        <h3>Résultat du Match</h3>
        <div class="detail-odds-grid">
          ${detailOddBox("1", homeOdd, "Domicile", favoritePick === "1")}
          ${detailOddBox("X", drawOdd, "Match nul", favoritePick === "X")}
          ${detailOddBox("2", awayOdd, "Extérieur", favoritePick === "2")}
        </div>

        <h3>Double Chance</h3>
        <div class="detail-odds-grid">
          ${detailOddBox("1X", deriveDoubleChanceOdd(homeOdd, drawOdd), "Domicile/Nul", marketAnalysis.doubleChance.pick === "1X")}
          ${detailOddBox("X2", deriveDoubleChanceOdd(drawOdd, awayOdd), "Nul/Extérieur", marketAnalysis.doubleChance.pick === "X2")}
          ${detailOddBox("12", deriveDoubleChanceOdd(homeOdd, awayOdd), "Domicile/Extérieur", marketAnalysis.doubleChance.pick === "12")}
        </div>
      </section>

      <section class="alternate-market-card">
        <div class="detail-section-title"><span>⇄</span><strong>Marchés Alternatifs</strong><b>?</b></div>
        <div class="market-table">
          <div class="market-head"><span>Marché</span><span>Prédiction</span><span>Cotes</span><span>Prob.</span><span></span></div>
          ${marketRow("Classique", favoritePick, oddForPick(match, favoritePick), match.percent)}
          ${marketRow("Les Deux Marquent", marketAnalysis.btts.pick, match.bestOdds?.totals?.odds || "—", marketAnalysis.btts.confidence)}
          ${marketRow(`${favoritePick === "2" ? "Extérieur" : "Domicile"} Plus de 0.5`, "Oui", "—", marketAnalysis.handicap.confidence)}
          ${marketAnalysis.totalGoals.pick?.startsWith("Over")
            ? marketRow("Total buts", marketAnalysis.totalGoals.pick, match.bestOdds?.totals?.odds || "—", marketAnalysis.totalGoals.confidence)
            : marketRow("Handicap prudent", marketAnalysis.handicap.pick, "—", marketAnalysis.handicap.confidence)}
        </div>
      </section>

      <section class="team-strength-section" id="detail-stats">
        <div class="detail-section-title plain"><span>↗</span><strong>Force de l'Équipe</strong></div>
        <article class="strength-card">
          <h3>Évaluation de la Force de l'Équipe (0-5)</h3>
          <p>Basé sur la forme récente, la position en ligue et les performances historiques</p>
          <small>ⓘ 3.0+ est considéré comme exceptionnellement fort</small>
          ${strengthBar(match.home, homeStrength, "home")}
          ${strengthBar(match.away, awayStrength, "away")}
          <div class="strength-note">↪ ${homeStrength >= awayStrength ? match.home : match.away} a un avantage de force significatif</div>
        </article>
      </section>

      <section class="h2h-section" id="detail-h2h">
        ${history.loading ? detailLoadingCard("Chargement des vrais 10 derniers matchs...") : ""}
        ${recentTeamForm(match.home, match.homeLogo, match.homeTeamId, history.homeLast10, "home")}
        ${recentTeamForm(match.away, match.awayLogo, match.awayTeamId, history.awayLast10, "away")}
        ${recentH2hBlock(match, history.h2hLast10)}
      </section>
    </section>
  `);

  bindOpenPageButtons();
  bindDetailTabs();
}

function fallbackHandicap(match) {
  const pick = match.ai?.oneXTwo || match.prediction;
  if (pick === "1") return match.percent >= 78 ? "1 (-0.5)" : "1 (0)";
  if (pick === "2") return match.percent >= 78 ? "2 (-0.5)" : "2 (0)";
  return "X (+0.5)";
}

function normalizedMarketAnalysis(match) {
  const analysis = match.ai?.marketAnalysis || {};
  const base = Number(match.percent) || Number(match.ai?.confidence) || 62;
  return {
    doubleChance: analysis.doubleChance || {
      pick: match.ai?.doubleChance || "1X",
      confidence: Math.min(94, base + 6),
      explanation: "Sélection protégée selon le favori bookmaker, la forme des 5 derniers matchs et le H2H récent.",
    },
    btts: analysis.btts || {
      pick: match.ai?.btts || "Non",
      confidence: Math.max(42, base - 6),
      explanation: "Analyse basée sur la fréquence de buts marqués/encaissés dans les 5 derniers matchs.",
    },
    totalGoals: analysis.totalGoals || {
      pick: (match.ai?.totalGoals || match.ai?.overUnder25 || "").startsWith("Over") ? (match.ai?.totalGoals || match.ai?.overUnder25) : "",
      confidence: Math.max(42, base - 4),
      explanation: "Total estimé avec les formes offensives/défensives récentes. Si Over n'est pas validé, l'IA privilégie Double Chance ou Handicap.",
    },
    handicap: analysis.handicap || {
      pick: match.ai?.handicap || fallbackHandicap(match),
      confidence: Math.max(42, base - 8),
      explanation: "Handicap calculé avec prudence selon le favori, l'écart de forme et les confrontations directes.",
    },
  };
}

function bindDetailTabs() {
  document.querySelectorAll("[data-detail-scroll]").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll("[data-detail-scroll]").forEach((item) => item.classList.toggle("active", item === button));
      document.querySelector(`#${button.dataset.detailScroll}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}

function matchDateLabel(match) {
  if (!match.kickoff) return "Jun 13, 2026";
  return new Date(match.kickoff).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function oddForPick(match, pick) {
  return h2hOddForPick(match, pick)?.odds || "—";
}

function deriveDoubleChanceOdd(first, second) {
  const values = [Number(first), Number(second)].filter((value) => Number.isFinite(value) && value > 1);
  if (!values.length) return "—";
  return Math.max(1.15, Math.min(...values) - 0.45).toFixed(2);
}

function detailOddBox(label, odd, sub, active = false) {
  return `
    <article class="detail-odd ${active ? "recommended" : ""}">
      <strong>${label}</strong>
      <b>${formatWorldOdd(odd)}</b>
      <span>${sub}</span>
      ${active ? "<em>RECOMMANDÉ</em>" : ""}
    </article>
  `;
}

function marketRow(label, prediction, odd, probability) {
  return `
    <div class="market-row">
      <span>${label}</span>
      <b>${prediction}</b>
      <strong>${formatWorldOdd(odd)}</strong>
      <em>${probability}%</em>
      <i>＋</i>
    </div>
  `;
}

async function loadMatchDetailHistory(match) {
  if (!match.homeTeamId || !match.awayTeamId) return { unavailable: true };
  const key = `${match.homeTeamId}-${match.awayTeamId}`;
  if (detailHistoryCache.has(key)) return detailHistoryCache.get(key);
  try {
    const [homeLast10, awayLast10, h2hLast10] = await Promise.all([
      apiFootballFetch("/fixtures", { team: match.homeTeamId, last: 10 }),
      apiFootballFetch("/fixtures", { team: match.awayTeamId, last: 10 }),
      apiFootballFetch("/fixtures/headtohead", { h2h: key, last: 10 }),
    ]);
    const history = { homeLast10, awayLast10, h2hLast10 };
    detailHistoryCache.set(key, history);
    return history;
  } catch (error) {
    return { error: true, homeLast10: [], awayLast10: [], h2hLast10: [] };
  }
}

function detailLoadingCard(text) {
  return `<article class="recent-card detail-loading">${text}</article>`;
}

function teamStrength(match, side, fixtures = []) {
  if (fixtures?.length) {
    const teamId = side === "home" ? match.homeTeamId : match.awayTeamId;
    const stats = formStats(fixtures.slice(0, 5), teamId, "all");
    const balance = stats.goalsFor - stats.goalsAgainst;
    return Math.max(0.35, Math.min(5, 1 + stats.wins * 0.7 + stats.draws * 0.25 + balance * 0.18));
  }
  const seed = side === "home" ? match.homeTeamId || match.home.length : match.awayTeamId || match.away.length;
  const confidence = Number(match.percent) || 62;
  const base = side === "home" ? confidence / 28 : confidence / 27 + 0.2;
  return Math.max(0.35, Math.min(4.8, base + (seed % 7) / 10));
}

function strengthBar(team, value, side) {
  const percent = Math.max(8, Math.min(96, (value / 5) * 100));
  return `
    <div class="strength-row ${side}">
      <span>${team}</span>
      <div><i style="--strength:${percent}%"></i></div>
      <b>${value.toFixed(2)}</b>
    </div>
  `;
}

function fixtureOutcome(item, teamId) {
  const isHome = item.teams.home.id === teamId;
  const teamGoals = Number(isHome ? item.goals.home : item.goals.away);
  const oppGoals = Number(isHome ? item.goals.away : item.goals.home);
  if (!Number.isFinite(teamGoals) || !Number.isFinite(oppGoals)) return "D";
  if (teamGoals > oppGoals) return "W";
  if (teamGoals < oppGoals) return "L";
  return "D";
}

function recentTeamForm(team, logo, teamId, fixtures = [], side) {
  if (!fixtures?.length) {
    return `
      <section class="recent-form-block">
        <div class="recent-title"><span>${side === "home" ? "⌂" : "⌁"}</span><strong>10 derniers matches: ${team}</strong></div>
        <article class="recent-card empty-recent">Données réelles indisponibles pour cette équipe.</article>
      </section>
    `;
  }
  const sequence = fixtures.slice(0, 10).map((item) => fixtureOutcome(item, teamId));
  const rows = fixtures.slice(0, 10).map((item) => recentResultRow(item, teamId)).join("");
  return `
    <section class="recent-form-block">
      <div class="recent-title"><span>${side === "home" ? "⌂" : "⌁"}</span><strong>10 derniers matches: ${team}</strong></div>
      <article class="recent-card">
        <header>${teamLogo(team, logo)}<strong>${team}</strong></header>
        <div class="form-strip">${sequence.map((item) => `<b class="${item.toLowerCase()}">${item}</b>`).join("")}</div>
        ${rows}
      </article>
    </section>
  `;
}

function recentResultRow(item, teamId) {
  const result = fixtureOutcome(item, teamId);
  const date = new Date(item.fixture.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" });
  const home = item.teams.home;
  const away = item.teams.away;
  const homeGoals = item.goals.home ?? "-";
  const awayGoals = item.goals.away ?? "-";
  return `
    <div class="recent-row">
      <time>${date}</time>
      <div>
        <span>${teamLogo(home.name, home.logo)} <strong>${home.name}</strong></span>
        <span>${teamLogo(away.name, away.logo)} <strong>${away.name}</strong></span>
      </div>
      <div class="recent-score"><b>${homeGoals}</b><b>${awayGoals}</b></div>
      <em class="${result.toLowerCase()}">${result}</em>
    </div>
  `;
}

function recentH2hBlock(match, fixtures = []) {
  if (!fixtures?.length) {
    return `
      <section class="recent-form-block">
        <div class="recent-title"><span>↔</span><strong>10 derniers face-à-face</strong></div>
        <article class="recent-card empty-recent">Aucun face-à-face réel disponible pour ce match.</article>
      </section>
    `;
  }
  const rows = fixtures.slice(0, 10).map((item) => recentResultRow(item, match.homeTeamId)).join("");
  return `
    <section class="recent-form-block">
      <div class="recent-title"><span>↔</span><strong>10 derniers face-à-face</strong></div>
      <article class="recent-card">
        <header>${teamLogo(match.home, match.homeLogo)}<strong>${match.home} vs ${match.away}</strong></header>
        ${rows}
      </article>
    </section>
  `;
}

function analysisMarketCard(title, analysis, fallbackPick) {
  const pick = analysis?.pick || fallbackPick || "Analyse en cours";
  const confidence = analysis?.confidence ? `${analysis.confidence}%` : "--";
  const explanation = analysis?.explanation || "Basé sur les cotes bookmaker, les 5 derniers matchs et les 5 derniers face-à-face.";
  return `
    <article class="analysis-market-card">
      <div><span>${title}</span><b>${confidence}</b></div>
      <strong>${pick}</strong>
      <p>${explanation}</p>
    </article>
  `;
}

function renderLive() {
  if (!liveFeed) return;
  liveFeed.innerHTML = liveMatches
    .map(
      (match) => `
        <article class="live-card">
          <div class="live-badge">● LIVE ${match.minute}</div>
          <div class="live-teams">
            ${teamLogo(match.home, match.homeLogo)}
            <strong>${match.home}</strong>
            <b>${match.score}</b>
            <strong>${match.away}</strong>
            ${teamLogo(match.away, match.awayLogo)}
          </div>
        </article>
      `,
    )
    .join("");
}

function renderFeed() {
  const query = searchInput.value.trim().toLowerCase();
  const sections = homeLeagues()
    .map((league) => {
      const visibleMatches = league.matches
        .filter((match) => matchVisible(match, league, query))
        .slice(0, hasProAccess() ? league.matches.length : FREE_AI_PICK_LIMIT);
      if (!visibleMatches.length) return "";

      const isCollapsed = collapsedLeagues.has(league.id);
      return `
        <section class="league-section">
          <header class="league-header">
            ${leagueLogo(league)}
            <div class="league-title">
              <strong>${league.name}</strong>
              <span>${league.country}</span>
            </div>
            <button class="league-fav ${favoriteLeagues.has(league.id) || league.favorite ? "faved" : ""}" type="button" aria-label="Favori ligue" data-league-fav="${league.id}">♡</button>
            <button class="league-toggle" type="button" aria-label="Ouvrir fermer" data-collapse="${league.id}">${isCollapsed ? "⌃" : "⌄"}</button>
          </header>
          <div class="match-list" ${isCollapsed ? "hidden" : ""}>${visibleMatches.map(matchCard).join("")}</div>
        </section>
      `;
    })
    .filter(Boolean)
    .join("");

  leagueFeed.innerHTML =
    sections || `<div class="empty-state">Aucune prédiction trouvée pour ce filtre.</div>`;

  document.querySelectorAll("[data-collapse]").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.collapse;
      if (collapsedLeagues.has(id)) {
        collapsedLeagues.delete(id);
      } else {
        collapsedLeagues.add(id);
      }
      renderFeed();
    });
  });

  document.querySelectorAll("[data-league-fav]").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.leagueFav;
      if (favoriteLeagues.has(id)) {
        favoriteLeagues.delete(id);
      } else {
        favoriteLeagues.add(id);
      }
      saveFavorites();
      renderFeed();
      renderPages();
    });
  });

  bindMatchActions();
}

function compactList(matches, limit = 5) {
  return matches
    .slice(0, limit)
    .map(({ league, ...match }) => {
      const oddText = match.odds || "Cote indisponible";
      const locked = match.vip ? `<span class="mini-lock">🔒 VIP</span>` : `<span>${match.percent}% · ${oddText}</span>`;
      return `
        <div class="mini-row">
          <span>${league.flag}</span>
          <strong>${match.home} - ${match.away}</strong>
          ${locked}
        </div>
      `;
    })
    .join("");
}

function aiCard({ league, ...match }) {
  const market = match.ai.marketProbabilities;
  const marketLine = market
    ? `<div class="risk-line">Marché: 1 ${(market.home * 100).toFixed(0)}% · X ${(market.draw * 100).toFixed(0)}% · 2 ${(market.away * 100).toFixed(0)}%</div>`
    : "";
  return `
    <article class="ai-pick-card">
      <div class="ai-pick-head">
        <span>🤖 IA Pick</span>
        <b>Confiance: ${match.ai.confidence}% · Risque: ${match.ai.risk}</b>
      </div>
      <strong>${league.flag} ${match.home} - ${match.away}</strong>
      <div class="ai-market-grid">
        <span>1X2 <b>${match.ai.oneXTwo}</b></span>
        <span>Double chance <b>${match.ai.doubleChance}</b></span>
        <span>BTTS <b>${match.ai.btts}</b></span>
        <span>O/U 2.5 <b>${match.ai.overUnder25}</b></span>
      </div>
      <div class="risk-line">Risque: ${match.ai.risk}</div>
      ${marketLine}
      <p>${match.ai.explanation}</p>
    </article>
  `;
}

function formatWorldOdd(value) {
  if (!value) return "—";
  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(2) : value;
}

function worldOddButton(label, odd, active = false) {
  return `
    <div class="world-odd ${active ? "active" : ""}">
      <span>${label}</span>
      <strong>${formatWorldOdd(odd)}</strong>
    </div>
  `;
}

function worldPredictionTitle(match) {
  if (match.market === "O/U") {
    if (String(match.prediction).includes("+")) return `Plus de ${String(match.prediction).replace("+", "")} buts`;
    return String(match.prediction).replace("Over", "Plus de");
  }
  if (match.market === "DC") return `Double chance ${match.prediction}`;
  if (match.market === "HCP") return `Handicap ${match.prediction}`;
  if (match.market === "BTTS") return "Les deux marquent";
  if (["1", "1X"].includes(match.prediction)) return `${match.home} gagne`;
  if (["2", "X2"].includes(match.prediction)) return `${match.away} gagne`;
  return match.prediction === "X" ? `Double chance ${match.ai?.doubleChance || "1X"}` : match.prediction;
}

function worldRecommended(match) {
  const marketOdd = oddsForDisplayedMarket(match);
  const odd = marketOdd?.odds || h2hOddForPick(match)?.odds || null;
  const label = worldPredictionTitle(match);
  return `
    <div class="world-reco">
      <div>
        <span>RECOMMANDÉ</span>
        <strong>${label}</strong>
      </div>
      <b>@ ${formatWorldOdd(odd)}</b>
      <em>${match.percent}%</em>
    </div>
  `;
}

function worldConfidenceRows(match) {
  const favoritePick = match.ai?.bookmakerFavorite?.pick || match.ai?.oneXTwo || match.prediction;
  const favoriteOdd = h2hOddForPick(match, favoritePick)?.odds;
  const dcPick = favoritePick === "2" ? "X2" : "1X";
  const totalPick = match.ai?.marketAnalysis?.totalGoals?.pick || match.ai?.totalGoals || "";
  const showOver = totalPick.startsWith("Over");
  const btts = Math.max(38, Math.min(72, Math.round(match.percent * 0.72)));
  return `
    <div class="world-confidence">
      <div class="world-confidence-row">
        <span>Double chance ${dcPick}</span>
        <b>@ — · ${Math.max(55, Math.round(match.percent * 0.84))}%</b>
        <i style="--value:${Math.max(55, Math.round(match.percent * 0.84))}%"></i>
      </div>
      <div class="world-confidence-row">
        <span>${showOver ? totalPick.replace("Over", "Plus de") + " buts" : `Handicap ${favoritePick === "2" ? "2 (0)" : "1 (0)"}`}</span>
        <b>@ ${showOver ? formatWorldOdd(match.bestOdds?.totals?.odds) : "—"} · ${Math.max(48, Math.round(match.percent * 0.72))}%</b>
        <i style="--value:${Math.max(48, Math.round(match.percent * 0.72))}%"></i>
      </div>
      <div class="world-confidence-row">
        <span>${favoritePick === "1" ? match.home : favoritePick === "2" ? match.away : "Favori"} protégé</span>
        <b>@ ${formatWorldOdd(favoriteOdd)} · ${btts}%</b>
        <i style="--value:${btts}%"></i>
      </div>
    </div>
  `;
}

function worldCupMatchCard(match, groupLabel) {
  const homeOdd = match.bestOdds?.h2hAll?.home?.odds;
  const drawOdd = match.bestOdds?.h2hAll?.draw?.odds;
  const awayOdd = match.bestOdds?.h2hAll?.away?.odds;
  const key = `${match.home}-${match.away}`;
  return `
    <article class="world-match-card" role="button" tabindex="0" data-match-key="${key}">
      <div class="world-match-top">
        <span>${match.dateLabel || "12 Jun"} · ${match.time} · ${match.venue || "Stade"}</span>
        <b>${groupLabel}</b>
      </div>
      <div class="world-teams">
        <div class="world-team">
          ${teamLogo(match.home, match.homeLogo || match.home.slice(0, 2))}
          <strong>${match.home}</strong>
        </div>
        <span>VS</span>
        <div class="world-team">
          ${teamLogo(match.away, match.awayLogo || match.away.slice(0, 2))}
          <strong>${match.away}</strong>
        </div>
      </div>
      <div class="world-odds-grid">
        ${worldOddButton("1", homeOdd, match.prediction === "1")}
        ${worldOddButton("X", drawOdd, match.prediction === "X")}
        ${worldOddButton("2", awayOdd, match.prediction === "2")}
      </div>
      ${worldRecommended(match)}
      ${worldConfidenceRows(match)}
    </article>
  `;
}

function renderWorldCupPage(world) {
  const nextMatch = world[0] || {
    home: "Canada",
    away: "Bosnia & Herzegovina",
    time: "15:00",
    percent: 69,
    prediction: "1",
    market: "1X2",
  };
  const visibleMatches = world.length ? world.slice(0, 8) : [nextMatch];
  const groupNames = ["GROUPE A", "GROUPE B", "GROUPE C", "GROUPE D"];
  const groupHtml = visibleMatches
    .map((match, index) => {
      const groupIndex = Math.floor(index / 2);
      const groupLabel = `Groupe ${String.fromCharCode(65 + groupIndex)}`;
      const title = index % 2 === 0 ? `<h3 class="world-group-title">${groupNames[groupIndex] || "PHASE FINALE"}</h3>` : "";
      return `${title}${worldCupMatchCard(match, groupLabel)}`;
    })
    .join("");

  return `
    <section class="world-page">
      <div class="world-hero">
        <div class="world-title">
          <h2>🏆 World Cup 2026</h2>
          <span>USA / Canada / Mexico</span>
          <em>Mis à jour · ${apiFootballConnected ? "API-Football actif" : "données en attente"}</em>
        </div>
      </div>

      <div class="world-stat-grid">
        <div><span>📅</span><b>${Math.min(world.length, 2)}</b><small>Aujourd'hui</small></div>
        <div><span>⚽</span><b>${world.length}/104</b><small>Matchs</small></div>
        <div><span>👥</span><b>48</b><small>Équipes</small></div>
      </div>

      <article class="world-next-card">
        <div class="world-next-label"><span>◷ Prochain match</span><b>Groupe B</b></div>
        <div class="world-next-teams">
          <span>${teamLogo(nextMatch.home, nextMatch.homeLogo || nextMatch.home?.slice(0, 2) || "CA")} ${nextMatch.home}</span>
          <strong>${nextMatch.time}</strong>
          <span>${nextMatch.away} ${teamLogo(nextMatch.away, nextMatch.awayLogo || nextMatch.away?.slice(0, 2) || "BO")}</span>
        </div>
      </article>

      <article class="world-insight-card"><span>🏆 Vainqueur du tournoi</span><strong>Spain 18.6%</strong><b>›</b></article>
      <article class="world-insight-card"><span>⚽ Meilleur buteur</span><strong>Kylian Mbappé 20.0%</strong><b>›</b></article>

      <div class="world-tabs">
        <button class="active">Tous</button>
        <button>Groupes</button>
        <button>16es</button>
        <button>8es</button>
        <button>Quarts</button>
        <button>Demi</button>
      </div>

      ${groupHtml}
    </section>
  `;
}

function renderPages() {
  const matches = allMatches();
  const userPromo = ensureUserPromo();
  const firebaseClient = window.ADPronoFirebase;
  const currentUser = firebaseClient?.getCurrentUser?.();
  const userIsPro = hasProAccess();
  const userIsAdmin = isAdminUser();
  const firebaseStatus = firebaseClient?.isConnected?.() ? "Firebase Connected" : "Firebase local preview";
  const expertPicks = matches.filter(({ source, vip }) => source === "expert" && !vip);
  const aiPicks = matches.filter(({ source }) => source === "ai");
  const visibleAiPicks = userIsPro ? aiPicks : aiPicks.slice(0, FREE_AI_PICK_LIMIT);
  const world = worldCupFixtures.length
    ? worldCupFixtures.map((match) => ({
        ...match,
        league: { id: "world", flag: "🏆", name: "World Cup 2026", country: "International" },
      }))
    : matches.filter(({ league }) => league.id === "world");
  const vip = matches.filter(({ vip }) => vip);
  const userCountry = country();
  const standingsText = standingsData.length
    ? `${standingsLeagueLabel}: ${standingsData.map((row) => `${row.rank}. ${row.team} ${row.points} pts`).join(" · ")}`
    : "Standings en attente API-Football";

  setPage("world-cup", renderWorldCupPage(world, standingsText));

  setPage("pro", `
    <h2>👑 Pronostics PRO</h2>
    ${userIsPro
      ? `<p class="page-count">${expertPicks.length} picks Expert/Admin</p>${compactList(expertPicks, 10)}`
      : proAccessCard(userCountry)}
  `);

  setPage("vip", `
    <h2>🔒 Pronostics VIP</h2>
    <p class="page-count">${vip.length} picks VIP Expert</p>
    ${vip.length ? compactList(vip, 12) : miniCard("VIP Expert", "Aucun pick VIP publié pour le moment.")}
  `);

  setPage("experts", `
    <section class="experts-page">
      <h2>Experts</h2>
      <div class="expert-tabs"><button class="active">Tous</button><button>Très Sûr</button><button>Sûr</button><button class="expert-filter">≡</button></div>
      ${expertCard({
        name: "Balanced Ben",
        tag: "SÛR",
        text: "A strategic approach mixing safe bets to reach a solid daily odd. The classic bettor.",
        today: "Aujourd'hui @1.40  (2 picks)",
        roi: "+218% (365d)",
        win: "59% V",
        odd: "1.8x",
        streak: "17 jours 🔥",
        week: ["w", "w", "w", "w", "w", "l", "q"],
        photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=70",
        analyses: [
          { market: "Analyse PRO verrouillée", proPrice: userCountry.proPrice, proPickPrice: userCountry.proPickPrice },
          { market: "Analyse PRO verrouillée", proPrice: userCountry.proPrice, proPickPrice: userCountry.proPickPrice },
        ],
      }, userIsPro)}
      ${expertCard({
        name: "Safe Steve",
        tag: "TRÈS SÛR",
        text: "Focuses on the safest available predictions each day. Minimizes risk for consistent gains.",
        today: "Aujourd'hui @1.85  (3 picks)",
        roi: "+80% (365d)",
        win: "61% V",
        odd: "1.4x",
        streak: "17 jours 🔥",
        week: ["l", "w", "w", "w", "w", "l", "q"],
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=160&q=70",
        analyses: [
          { market: "Analyse PRO verrouillée", proPrice: userCountry.proPrice, proPickPrice: userCountry.proPickPrice },
          { market: "Analyse PRO verrouillée", proPrice: userCountry.proPrice, proPickPrice: userCountry.proPickPrice },
          { market: "Analyse PRO verrouillée", proPrice: userCountry.proPrice, proPickPrice: userCountry.proPickPrice },
        ],
      }, userIsPro)}
      ${userIsPro ? miniCard("PRO actif", "Toutes les analyses Expert sont visibles.") : proAccessCard(userCountry)}
      <p class="expert-more">👥<br>D'autres experts rejoindront le programme bientôt.<br>Restez connecté !</p>
    </section>
  `);

  setPage("strategy", `
    <section class="strategy-page">
      <h2>Win+ Strategy</h2>
      <div class="strategy-tabs"><span class="active">Strategy</span><span>Simulator</span></div>

      <section class="strategy-hero">
        <span>★ PREMIUM STRATEGY</span>
        <h3>Win+ Strategy</h3>
        <p>Gagnez même après 3 pertes consécutives</p>
        <div>
          <b><strong>95%+</strong><small>Win Rate</small></b>
          <b><strong>15-25%</strong><small>Monthly ROI</small></b>
          <b><strong>4-5</strong><small>Safety Nets</small></b>
        </div>
        <button data-open-page="subscription">Unlock Strategy 🔒</button>
      </section>

      <section class="strategy-safety-card">
        <div class="strategy-card-head">
          <span class="strategy-icon blue">🛡</span>
          <div><strong>Multi-Chance Safety</strong><small>Lose 3 times, still profit on the 4th</small></div>
          <button type="button">↻</button>
        </div>
        <div class="bet-steps">
          <article class="lose"><span>×</span><div><strong>Bet 1</strong><small>€15 @ 1.07</small></div><em>If won<br><b>+€1</b></em><strong>LOSE<br><small>€-15</small></strong></article>
          <article class="lose"><span>×</span><div><strong>Bet 2</strong><small>€80 @ 1.25</small></div><em>If won<br><b>+€5</b></em><strong>LOSE<br><small>€-95</small></strong></article>
          <article class="lose"><span>×</span><div><strong>Bet 3</strong><small>€128 @ 1.50</small></div><em>If won<br><b>+€15</b></em><strong>LOSE<br><small>€-223</small></strong></article>
          <article class="win"><span>4</span><div><strong>Bet 4</strong><small>€233 @ 2.15</small></div><em>If won<br><b>+€25</b></em><strong>WIN<br><small>+€25</small></strong></article>
        </div>
      </section>

      <section class="strategy-info-card how-card">
        <div class="strategy-card-head compact">
          <span class="strategy-icon green">💡</span>
          <div><strong>How It Works</strong><small>Simple 4-step process</small></div>
        </div>
        <div class="steps-list">
          <article><b>1</b><div><strong>Sélectionnez un Match à Beaucoup de Buts</strong><span>Identifiez les matchs avec le taux de réussite le plus élevé</span></div></article>
          <article><b>🔒</b><div><strong>Bet on the Secret Market</strong><span>Découvrez le marché avec 88-92% de probabilité</span></div></article>
          <article><b>3</b><div><strong>Progressez si Nécessaire</strong><span>Utilisez le système multi-chance pour récupérer les pertes + profit</span></div></article>
        </div>
        <aside class="key-insight"><span>💡</span><div><strong>The Key Insight</strong><p>Avec notre marché secret, la probabilité de perdre les 4 paris est statistiquement proche de zéro.</p></div></aside>
      </section>

      <section class="strategy-info-card market-card">
        <div class="strategy-card-head compact">
          <span class="strategy-icon green">⚽</span>
          <div><strong>The Secret Market <em>🔒 LOCKED</em></strong><small>The safest market in football betting</small></div>
        </div>
        <h3>Match Outcome Probability</h3>
        <div class="probability-bar"><span>~90%<small>You Win</small></span><b>10%<small>Next</small></b></div>
        <div class="legend"><span>You Win</span><span>Next Bet</span></div>
        <div class="market-points">
          <article><span>↗</span><div><strong>88-92% probability</strong><small>Base win rate with the secret market</small></div></article>
          <article><span>🛡</span><div><strong>Only 8-12% failure rate</strong><small>Marché à plus faible risque disponible</small></div></article>
          <article><span>▣</span><div><strong>0.0001% de chance</strong><small>de 4 échecs consécutifs avec une sélection appropriée</small></div></article>
        </div>
      </section>

      <section class="strategy-unlock">
        <div class="medal">🏅</div>
        <h3>Unlock Win+ Strategy</h3>
        <p>Everything you need to profit consistently</p>
        <ul>
          <li><span>📖</span>Complete step-by-step guide <b>✓</b></li>
          <li><span>🧮</span>Advanced bankroll calculator <b>✓</b></li>
          <li><span>☑</span>Match selection criteria <b>✓</b></li>
          <li><span>⚙</span>Risk management protocols <b>✓</b></li>
          <li><span>⚽</span>Lifetime access & updates <b>✓</b></li>
        </ul>
        <div class="unlock-trust"><span>🔒<small>Secure</small></span><span>⟳<small>Money-back</small></span><span>∞<small>Lifetime</small></span></div>
        <button data-open-page="subscription">★ Unlock Premium Access</button>
        <small>One-time purchase • No subscription</small>
      </section>
    </section>
  `);

  setPage("ai", `
    <div class="ai-header"><b>Nouvelle Conversation</b><span>Genius AI · 3/3 réponses gratuites</span></div>
    <article class="chat-card">
      <strong>Bienvenue dans AD PRONO Genius AI! 🚀</strong>
      <p>Je suis votre assistant premium pour analyser les matchs, les formes d'équipes, les cotes et la gestion du risque.</p>
      <p><b>Conseil Pro:</b> ajoutez jusqu'à 5 matchs depuis les pronostics pour une analyse plus précise.</p>
      <em>Quel match voulez-vous explorer aujourd'hui?</em>
    </article>
    ${miniCard("Moteur IA", apiReady.aiInputs.join(" · "))}
    ${miniCard("Moteur connecté", `${aiEngineConnected ? "API-Football + Odds API actifs" : "Analyse en cours"} · IA picks seulement`)}
    ${miniCard("Sorties IA", apiReady.aiOutputs.join(" · "))}
    ${!userIsPro ? miniCard("FREE", `${FREE_AI_PICK_LIMIT} picks IA gratuits affichés. Passe en PRO pour tout débloquer.`) : miniCard("PRO", "Tous les picks IA et PRO sont déverrouillés.")}
    <section class="ai-pick-list">
      ${visibleAiPicks.map(aiCard).join("")}
    </section>
    <div class="prompt-row"><button>🏆 Meilleurs Choix</button><button>🔎 Analyse Match</button><button>📊 Stratégie Paris</button></div>
    <div class="input-row"><span>Demandez-moi des prédictions de paris...</span><button>➤</button></div>
  `);

  setPage("subscription", `
    <h2>Abonnement</h2>
    ${firebaseBadge()}
    ${miniCard("Statut compte", currentUser ? `${currentUser.email} · ${currentUser.subscription || "FREE"}` : "Connecte-toi pour activer PRO")}
    ${miniCard("Pays sélectionné", `${userCountry.label} · ${userCountry.currency}`)}
    <article class="mini-card plan-card pro-only-plan">
      <strong>PRO</strong>
      <span>Toutes les analyses des experts sont dans PRO.</span>
      <div class="pro-plan-options">
        <button type="button" data-buy-pro="monthly"><b>${userCountry.proPrice}</b><small>Accès mensuel à toutes les analyses</small></button>
        <button type="button" data-buy-pro="single"><b>${userCountry.proPickPrice}</b><small>Une seule prédiction PRO</small></button>
      </div>
    </article>
    <article class="promo-code-card">
      <strong>Code promo</strong>
      <div><b>${userPromo.code}</b><button type="button" data-copy-promo="${userPromo.code}">Copier</button></div>
      <span>Quand 10 personnes prennent le plan mensuel avec ton code, tu gagnes 1 mois gratuit.</span>
      <small>${promoProgressText(userPromo)} · ${userPromo.freeMonths || 0} mois gratuit</small>
    </article>
    <label class="promo-input-card">
      <span>Ajouter un code promo</span>
      <input maxlength="4" placeholder="ABCD" />
    </label>
    ${miniCard("Paiements", userCountry.paymentMethods.join(" · "))}
    ${miniCard("Production", `${firebaseStatus} · PWA installable · Web app responsive`)}
  `);

  setPage("auth", `
    <h2>Compte AD PRONO</h2>
    ${firebaseBadge()}
    <div class="auth-tabs">
      <button type="button" class="active" data-auth-tab="login">Login</button>
      <button type="button" data-auth-tab="register">Register</button>
      <button type="button" data-auth-tab="reset">Reset</button>
    </div>
    <form class="compact-form active" data-auth-form="login">
      <strong>Login</strong>
      <input name="email" placeholder="Email" type="email" autocomplete="email" />
      <input name="password" placeholder="Password" type="password" autocomplete="current-password" />
      <button type="button" data-auth-submit onclick="window.ADPronoAuthSubmit(this)">Se connecter</button>
      <button type="button" class="social">Continue with Google</button>
      <button type="button" class="social">Continue with Apple</button>
    </form>
    <form class="compact-form" data-auth-form="register">
      <strong>Register</strong>
      <input name="email" placeholder="Email" type="email" autocomplete="email" />
      <input name="password" placeholder="Password" type="password" autocomplete="new-password" />
      <label class="auth-country-field">
        <span>Pays</span>
        <select name="country" data-register-country>
          <option value="haiti" ${selectedCountry === "haiti" ? "selected" : ""}>🇭🇹 Haïti</option>
          <option value="usa" ${selectedCountry === "usa" ? "selected" : ""}>🇺🇸 États-Unis</option>
          <option value="other" ${!selectedCountry || selectedCountry === "other" ? "selected" : ""}>🌍 Autre pays</option>
        </select>
      </label>
      <details class="promo-code-card compact-promo auth-promo">
        <summary>Ton code promo unique</summary>
        <div><b>${userPromo.code}</b><button type="button" data-copy-promo="${userPromo.code}">Copier</button></div>
        <span>4 lettres. 10 abonnements mensuels avec ton code = 1 mois gratuit.</span>
      </details>
      <button type="button" data-auth-submit onclick="window.ADPronoAuthSubmit(this)">Créer compte</button>
      <button type="button" class="social">Continue with Google</button>
      <button type="button" class="social">Continue with Apple</button>
    </form>
    <form class="compact-form" data-auth-form="reset">
      <strong>Forgot password</strong>
      <input name="email" placeholder="Email" type="email" autocomplete="email" />
      <button type="button" data-auth-submit onclick="window.ADPronoAuthSubmit(this)">Envoyer lien de récupération</button>
    </form>
  `);

  setPage("dashboard", `
    <h2>User dashboard</h2>
    <div class="page-stats"><span>Favoris</span><b>${starredMatches.size}</b><span>Notifications</span><b>9+</b></div>
    ${miniCard("Historique", "18 gagnés · 6 perdus · ROI +12.8%")}
    ${miniCard("Saved picks", "Picks sauvegardés synchronisés Firebase ready.")}
  `);

  setPage("admin", `
    <h2>Admin dashboard</h2>
    ${firebaseBadge()}
    ${userIsAdmin ? miniCard("Accès admin", `${currentUser.email} · role admin`) : ""}
    ${userIsAdmin ? `
    ${miniCard("Règle de publication", "IA picks = Free · Analyses Expert = payantes · Admin only · VIP après phases de groupes")}
    <form class="compact-form active admin-form">
      <input placeholder="Ligue / pays" value="Premier League · Belarus" />
      <input placeholder="Match" value="Belshina vs BATE Borisov" />
      <input placeholder="Prediction" value="1X2 · 2" />
      <select>
        <option>Prediction source: AI</option>
        <option selected>Prediction source: Expert</option>
      </select>
      <select>
        <option>Marquer Free</option>
        <option selected>Marquer PRO</option>
        <option>Marquer VIP</option>
      </select>
      <input placeholder="Expert name" value="Adams Pro" />
      <input placeholder="Expert win rate" value="78%" />
      <input placeholder="Expert note" value="Pick validé par analyse humaine." />
      <textarea placeholder="Analyse PRO payante">Analyse complète: favori bookmaker, 5 derniers matchs, H2H, double chance, BTTS, total buts et handicap.</textarea>
      <input placeholder="Cote" value="2.26" />
      <input placeholder="Pourcentage" value="49%" />
      <div class="quick-grid">
        <button type="button">Ajouter match</button>
        <button type="button">Modifier match</button>
        <button type="button">Supprimer match</button>
        <button type="button">Publier notification</button>
      </div>
    </form>
    <div class="quick-grid admin-grid">
      <button>Ajouter prediction</button>
      <button>Edit prediction</button>
      <button>Delete prediction</button>
      <button>Publish VIP pick</button>
      <button>Publish Expert pick</button>
      <button data-admin-action="publish-analysis">Publish paid analysis</button>
      <button>Send notification</button>
      <button>Add odds</button>
      <button>Confidence %</button>
      <button>Manage users</button>
      <button>Manage subscriptions</button>
    </div>
    ${miniCard("Firebase collections", apiReady.firebaseCollections.join(" · "))}
    ${miniCard("API sync", "API-Football fixtures/standings/logos · The Odds API odds/bookmakers · Auto refresh 60s")}
    ` : ""}
  `);

  setPage("notifications", `
    <h2>Notifications <span class="unread-count">9+</span></h2>
    ${notification("New VIP Picks", "3 nouveaux pronostics verrouillés sont disponibles.", "Maintenant")}
    ${notification("Match starts in 30 min", "France - Belgique commence bientôt.", "30 min")}
    ${notification("Odds changed", "Bayern passe de 1.82 à 1.76.", "2 min")}
    ${notification("Winning predictions", "Inter Milan BTTS validé.", "Live")}
    ${notification("World Cup alerts", "Canada - Bosnia ajouté aux fixtures.", "Nouveau")}
  `);

  setPage("settings", `
    <h2>Paramètres AD PRONO</h2>
    ${miniCard("Pays", `${userCountry.label} · Changer le pays ci-dessous`)}
    <div class="country-settings">
      <button data-country="haiti">🇭🇹 Haïti</button>
      <button data-country="usa">🇺🇸 États-Unis</button>
      <button data-country="other">🌍 Autre pays</button>
    </div>
    <section class="settings-card">
      <strong>Langue</strong>
      <span>Français</span>
      <span>English</span>
    </section>
    <section class="settings-card">
      <strong>Préférences</strong>
      <label>Dark mode <input type="checkbox" checked /></label>
      <label>Notifications <input type="checkbox" checked /></label>
      <label>Subscription <span>PRO</span></label>
      <label>Compte <span>adam.prono</span></label>
      <button type="button" class="settings-logout" data-auth-logout>Déconnexion</button>
    </section>
    ${miniCard("API-Football", `<b data-api-football-status>${apiFootballConnected ? "API-Football Connected" : "Connexion..."}</b> · ${footballServices.apiFootball.resources.join(" · ")} · Auto refresh 60s`)}
    ${miniCard("The Odds API", `<b data-odds-api-status>${oddsApiConnected ? "The Odds API Connected" : "Odds..."}</b> · ${footballServices.oddsApi.resources.join(" · ")} · Auto refresh 60s · Dernière cote ${shortTime(oddsLastUpdated)}`)}
    ${miniCard("Moteur IA", `${aiEngineConnected ? "Connecté" : "Analyse en cours"} · Forme · H2H · Classement · Cotes · Probabilités marché`)}
    ${miniCard("Firebase", `${firebaseStatus} · ${apiReady.firebaseCollections.join(" · ")}`)}
    ${miniCard("Paiements", apiReady.payments.join(" · "))}
    ${miniCard("Dernière sync", `<b data-sync-time>${footballServices.apiFootball.lastSync || "--:--"}</b>`)}
  `);

  setPage("profile", `
    <h2>Profil</h2>
    ${firebaseBadge()}
    <article class="profile-hero">
      <img class="profile-logo" src="assets/ad-prono-logo.jpg" alt="AD PRONO" />
      <strong>${currentUser?.email?.split("@")[0] || "adam.prono"}</strong>
      <span>${selectedCountry ? userCountry.label : "Pays non défini"} · ${currentUser?.subscription || "FREE"}</span>
    </article>
    ${userIsPro ? miniCard("PRO actif", "Analyses PRO déverrouillées") : miniCard("Subscription lock", "Les analyses PRO restent verrouillées jusqu'à l'abonnement.")}
    <div class="page-stats"><span>Équipes</span><b>${favoriteTeams.size}</b><span>Ligues</span><b>${favoriteLeagues.size}</b></div>
    ${miniCard("Favorite teams", [...favoriteTeams].join(" · ") || "Aucune équipe")}
    ${miniCard("Favorite leagues", [...favoriteLeagues].map((id) => leagues.find((league) => league.id === id)?.name || id).join(" · ") || "Aucune ligue")}
    ${miniCard("Favorites", `${starredMatches.size} prédictions sauvegardées`)}
    ${miniCard("Prediction history", "24 picks · 17 gagnés · 7 perdus")}
    ${userIsAdmin ? `<div class="quick-grid"><button type="button" data-open-page="admin">Admin Dashboard</button></div>` : ""}
    <button type="button" class="settings-logout profile-logout" data-auth-logout>Déconnexion</button>
    <article class="promo-code-card">
      <strong>Mon code promo</strong>
      <div><b>${userPromo.code}</b><button type="button" data-copy-promo="${userPromo.code}">Copier</button></div>
      <span>Partage ton code. 10 personnes avec le plan mensuel = 1 mois gratuit.</span>
      <small>${promoProgressText(userPromo)} · ${userPromo.freeMonths || 0} mois gratuit</small>
    </article>
    ${miniCard("Account settings", "Email · Password · Country · Notifications")}
    ${miniCard("Subscription", currentUser?.subscription === "PRO" ? `PRO actif · ${userCountry.proPrice}` : `FREE · upgrade ${userCountry.proPrice}`)}
  `);

  document.querySelectorAll("[data-open-page]").forEach((button) => {
    button.addEventListener("click", () => showScreen(button.dataset.openPage));
  });

  document.querySelectorAll("[data-country]").forEach((button) => {
    button.addEventListener("click", () => selectCountry(button.dataset.country));
  });

  bindOpenPageButtons();
}

function setPage(id, html) {
  document.querySelector(`[data-screen-panel="${id}"]`).innerHTML = html;
}

function profile(name, stat, rank, photo) {
  return `<article class="profile-card"><img class="avatar expert-photo" src="${photo}" alt="${name}" loading="lazy" /><div><strong>${name}</strong><span>${stat}</span></div><b>${rank}</b></article>`;
}

function proAccessCard(userCountry) {
  return `
    <article class="pro-access-card">
      <strong>PRO requis</strong>
      <span>Les picks PRO et analyses Expert sont réservés aux abonnés PRO.</span>
      <div>
        <button type="button" data-open-page="subscription">${userCountry.proPrice}</button>
        <button type="button" data-open-page="subscription">${userCountry.proPickPrice} / analyse</button>
      </div>
    </article>
  `;
}

function expertCard(expert, unlocked = false) {
  const days = ["Sa", "Su", "Mo", "Tu", "We", "Th", "Fr"];
  const week = expert.week.map((result, index) => `
    <span class="${result}">
      <b>${result === "w" ? "✓" : result === "l" ? "×" : "?"}</b>
      <small>${days[index]}</small>
    </span>
  `).join("");
  const analyses = unlocked ? (expert.analyses || []).map((analysis, index) => `
    <article class="expert-analysis-lock">
      <span>
        <strong>Analyse PRO ${index + 1}</strong>
        <small>Disponible pour compte PRO</small>
      </span>
      <em>Analyse Expert publiée</em>
      <div class="expert-pay-options">
        <button type="button">Voir analyse</button>
      </div>
    </article>
  `).join("") : "";
  return `
    <article class="expert-card-rich">
      <img src="${expert.photo}" alt="${expert.name}" loading="lazy" />
      <div class="expert-main">
        <div class="expert-name-row"><strong>${expert.name}</strong><em>${expert.tag}</em></div>
        <p>${expert.text}</p>
        <mark>● ${expert.today}</mark>
        <div class="expert-stats"><b>${expert.roi}</b><span>${expert.win}</span><i>${expert.odd}</i></div>
        <div class="expert-footer"><span>Meilleure série: ${expert.streak}</span><div>${week}</div></div>
      </div>
      ${unlocked ? `<div class="expert-locked-list">${analyses}</div>` : ""}
    </article>
  `;
}

function miniCard(title, text) {
  return `<article class="mini-card"><strong>${title}</strong><span>${text}</span></article>`;
}

function plan(name, price, text) {
  return `<article class="mini-card plan-card"><strong>${name}</strong><b>${price}</b><span>${text}</span></article>`;
}

function notification(title, text, time) {
  return `<article class="notification-card"><div><strong>${title}</strong><span>${text}</span></div><b>${time}</b></article>`;
}

function showScreen(screen) {
  let nextScreen = screen === "auth" || isAuthenticated() ? screen : "auth";
  if (nextScreen === "admin" && !isAdminUser()) nextScreen = isAuthenticated() ? "home" : "auth";
  activeScreen = nextScreen;
  document.querySelector(".phone-app")?.classList.toggle("auth-mode", nextScreen === "auth");
  countryGate.classList.remove("active");
  homePanel.classList.toggle("active", nextScreen === "home");
  panels.forEach((panel) => panel.classList.toggle("active", panel.dataset.screenPanel === nextScreen));
  bottomLinks.forEach((link) => link.classList.toggle("active", link.dataset.screen === nextScreen));
  if (window.location.hash !== `#${nextScreen}`) window.location.hash = nextScreen;
}

function selectCountry(id) {
  selectedCountry = id;
  localStorage.setItem("adprono.country", id);
  countryGate.classList.remove("active");
  renderPages();
  showScreen("home");
}

async function runAuthSubmit(form, actionButton) {
  const type = form.dataset.authForm;
  const email = form.elements.email?.value?.trim();
  const password = form.elements.password?.value || "adprono-demo-password";
  const registerCountry = form.elements.country?.value;
  if (!email) {
    form.dataset.status = "Email requis";
    return;
  }
  if (type === "register" && registerCountry) {
    selectedCountry = registerCountry;
    localStorage.setItem("adprono.country", registerCountry);
  }
  actionButton.disabled = true;
  actionButton.textContent = "Chargement...";
  try {
    if (type === "login") await window.ADPronoFirebase?.login(email, password);
    if (type === "register") await window.ADPronoFirebase?.register(email, password, { country: registerCountry || selectedCountry || "other" });
    if (type === "reset") await window.ADPronoFirebase?.resetPassword(email);
    form.dataset.status = type === "reset" ? "Lien envoyé" : "Connecté";
    renderPages();
    bindOpenPageButtons();
    if (type !== "reset") {
      showScreen("home");
    }
  } catch (error) {
    form.dataset.status = error.message || "Erreur Firebase";
    form.setAttribute("aria-label", form.dataset.status);
  } finally {
    actionButton.disabled = false;
    actionButton.textContent = type === "login" ? "Se connecter" : type === "register" ? "Créer compte" : "Envoyer lien de récupération";
  }
}

window.ADPronoAuthSubmit = (actionButton) => {
  const form = actionButton.closest("[data-auth-form]");
  if (form) runAuthSubmit(form, actionButton);
};

function bindOpenPageButtons() {
  document.querySelectorAll("[data-open-page]").forEach((button) => {
    button.onclick = () => showScreen(button.dataset.openPage);
  });
  document.querySelectorAll("[data-auth-tab]").forEach((button) => {
    button.onclick = () => {
      const target = button.dataset.authTab;
      document.querySelectorAll("[data-auth-tab]").forEach((tab) => {
        tab.classList.toggle("active", tab === button);
      });
      document.querySelectorAll("[data-auth-form]").forEach((form) => {
        form.classList.toggle("active", form.dataset.authForm === target);
      });
    };
  });
  document.querySelectorAll("[data-auth-form]").forEach((form) => {
    const actionButton = form.querySelector("[data-auth-submit]");
    if (!actionButton) return;
    actionButton.dataset.bound = "yes";
    actionButton.onclick = () => runAuthSubmit(form, actionButton);
  });
  document.querySelectorAll("[data-auth-logout]").forEach((button) => {
    button.onclick = async () => {
      button.disabled = true;
      button.textContent = "Déconnexion...";
      try {
        await window.ADPronoFirebase?.logout();
        renderPages();
        bindOpenPageButtons();
        showScreen("auth");
      } catch (error) {
        button.dataset.status = error.message || "Erreur Firebase";
      } finally {
        button.disabled = false;
        button.textContent = "Déconnexion";
      }
    };
  });
  document.querySelectorAll("[data-buy-pro]").forEach((button) => {
    button.onclick = async () => {
      button.disabled = true;
      button.dataset.status = "Activation...";
      try {
        await window.ADPronoFirebase?.saveSubscription("PRO", button.dataset.buyPro);
        renderPages();
        bindOpenPageButtons();
        showScreen("profile");
      } finally {
        button.disabled = false;
      }
    };
  });
  document.querySelectorAll("[data-admin-action='publish-analysis']").forEach((button) => {
    button.onclick = async () => {
      try {
        await window.ADPronoFirebase?.publishExpertPick?.({
          title: "Analyse PRO",
          note: "Analyse publiée par Admin",
          access: "PRO",
        });
        button.textContent = "Publié";
      } catch {
        button.textContent = "Admin requis";
      }
    };
  });
  document.querySelectorAll("[data-copy-promo]").forEach((button) => {
    button.onclick = async () => {
      const code = button.dataset.copyPromo;
      try {
        await navigator.clipboard?.writeText(code);
      } catch {
        // Clipboard can be blocked in preview mode; the visible code remains copyable.
      }
      button.textContent = "Copié";
      setTimeout(() => {
        button.textContent = "Copier";
      }, 1200);
    };
  });
}

function initCountryGate() {
  countryGate.classList.remove("active");
  countryGate.querySelectorAll("[data-country]").forEach((button) => {
    button.addEventListener("click", () => selectCountry(button.dataset.country));
  });
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.toggle("active", item === button));
    renderFeed();
  });
});

dayButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeDay = button.dataset.day;
    dayButtons.forEach((item) => item.classList.toggle("active", item === button));
    renderFeed();
  });
});

bottomLinks.forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    showScreen(link.dataset.screen);
  });
});

document.addEventListener("click", (event) => {
  const actionButton = event.target.closest("[data-auth-submit]");
  if (!actionButton || actionButton.dataset.bound === "yes") return;
  const form = actionButton.closest("[data-auth-form]");
  if (form) runAuthSubmit(form, actionButton);
});

searchInput.addEventListener("input", renderFeed);
window.addEventListener("hashchange", () => showScreen(location.hash.replace("#", "") || "auth"));
window.ADPronoFirebase?.onAuthStateChanged?.(() => {
  renderPages();
  bindOpenPageButtons();
  if (!isAuthenticated()) showScreen("auth");
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}

renderLive();
renderFeed();
renderPages();
showScreen("auth");
initCountryGate();
bindOpenPageButtons();
footballServices.refresh();
updatePredictionCount();
syncApiFootballData();
syncOddsApiData();
setInterval(() => footballServices.refresh(), 60000);
setInterval(() => syncApiFootballData(), API_FOOTBALL_REFRESH_MS);
setInterval(() => syncOddsApiData(), ODDS_API_REFRESH_MS);
setTimeout(() => document.querySelector(".phone-app")?.classList.remove("loading"), 450);
