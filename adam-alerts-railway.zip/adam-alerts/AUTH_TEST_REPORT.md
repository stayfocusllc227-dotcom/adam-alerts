# AD PRONO Authentication Test Report

Date: 2026-06-12
Test URL: http://127.0.0.1:4174/#auth
Firebase project: ad-prono

## Test Account

- Email: adprono.test.1781293352580@example.com
- Country selected: Haiti
- Expected Firestore collection: users

## Results

| Test | Result | Notes |
| --- | --- | --- |
| Firebase badge | Pass | Auth page displayed `Firebase Connected`. |
| Register new account | Partial pass | Firebase Auth account exists. Firestore user document creation failed. |
| Firebase Authentication user | Pass | REST verification returned `auth_ok: true` for the test email. |
| Firestore users document | Fail | REST verification returned `PERMISSION_DENIED: Missing or insufficient permissions.` for `users/MljCXNGWF8RSO6hXdKk22ATwhQx1`. |
| Logout | Pass | Clicking `Déconnexion` returned the app to `#auth` and showed `Compte AD PRONO`. |
| Login | Partial pass | Login accepted the test account and profile content updated with the test email, but the UI did not transition cleanly because Firestore read/write was blocked. |
| Forgot password | Pass via Firebase REST / UI status issue | Firebase Auth REST returned `reset_ok: true`. The in-app reset button still did not show a visible status during browser click testing. |

## Errors Found

1. Firestore rules are blocking the app from creating or reading user documents.

   Error:
   `FirebaseError: Missing or insufficient permissions.`

   Impact:
   - `users/{uid}` document is not created.
   - Register and login cannot complete cleanly.
   - Profile can receive Auth data, but Firestore-backed data is not verified.

2. Forgot password UI did not show a success or error status during the browser test.

   Impact:
   - Password reset works at Firebase Auth level.
   - The UI should still be retested after Firestore rules are fixed, because the current signed-in auth state keeps triggering Firestore permission errors.

## Direct Firebase Verification

Firebase Authentication:

```json
{
  "auth_ok": true,
  "email": "adprono.test.1781293352580@example.com",
  "localId": "MljCXNGWF8RSO6hXdKk22ATwhQx1",
  "error": null
}
```

Firestore users document:

```json
{
  "firestore_doc_ok": false,
  "name": null,
  "error_status": "PERMISSION_DENIED",
  "error_message": "Missing or insufficient permissions."
}
```

Forgot password:

```json
{
  "reset_ok": true,
  "email": "adprono.test.1781293352580@example.com",
  "error": null
}
```

## Code Fixes Applied During Test

- Added a real `Déconnexion` button on Profile and Settings.
- Fixed Register form binding so the promo `Copier` button is not mistaken for the submit button.
- Added safer Firebase auth-state handling so Firestore errors do not fully break the current Auth user session.
- Added stable submit hooks for Login, Register, and Forgot Password buttons.
- Bumped app cache versions so the browser loads the newest auth code.

## Required Firebase Rule Fix

Update Firestore rules so authenticated users can create and read their own profile document:

```txt
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow create, read, update: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

After publishing rules, rerun:

1. Register with a fresh email.
2. Confirm the Firebase Authentication user exists.
3. Confirm `users/{uid}` exists in Firestore.
4. Logout.
5. Login with the same email/password.
6. Send forgot-password email.
