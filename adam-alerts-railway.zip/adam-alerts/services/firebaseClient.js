(function () {
  const USER_KEY = "adprono.currentUser";
  const DB_PREFIX = "adprono.db.";
  const config = window.AD_PRONO_FIREBASE_CONFIG || {};
  const adminEmails = new Set((window.AD_PRONO_ADMIN_EMAILS || []).map((email) => email.toLowerCase()));
  const hasFirebaseConfig = Boolean(config.apiKey && config.projectId && config.appId);

  const collections = {
    users: "users",
    subscriptions: "subscriptions",
    favorites: "favorites",
    notifications: "notifications",
    expertPicks: "expert_picks",
    promoCodes: "promo_codes",
  };

  let firebase = null;
  let currentUser = read(USER_KEY, null);
  let firebaseConnected = false;
  let firebaseLastError = null;
  const listeners = new Set();

  function read(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
    return value;
  }

  function localCollection(name) {
    return read(`${DB_PREFIX}${name}`, []);
  }

  function saveLocalCollection(name, rows) {
    return write(`${DB_PREFIX}${name}`, rows);
  }

  function notify() {
    listeners.forEach((listener) => listener(currentUser));
  }

  function rememberFirebaseError(error) {
    firebaseLastError = error?.message || "Erreur Firebase";
    console.error(error);
    return firebaseLastError;
  }

  function promoCode() {
    return window.ensureUserPromo?.().code || "ADPR";
  }

  function normalizeUser(user) {
    if (!user) return null;
    const email = String(user.email || "").toLowerCase();
    const isAdmin = adminEmails.has(email);
    return {
      id: user.uid || user.id || `local-${Date.now()}`,
      email: user.email,
      country: localStorage.getItem("adprono.country") || "other",
      subscription: user.subscription || "FREE",
      promoCode: user.promoCode || promoCode(),
      createdAt: user.createdAt || new Date().toISOString(),
      role: isAdmin ? "admin" : "user",
      isAdmin,
    };
  }

  async function loadFirebase() {
    if (!hasFirebaseConfig || firebase) return firebase;
    const [
      appModule,
      authModule,
      firestoreModule,
    ] = await Promise.all([
      import("https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js"),
      import("https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js"),
      import("https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js"),
    ]);

    const app = appModule.initializeApp(config);
    const auth = authModule.getAuth(app);
    const db = firestoreModule.getFirestore(app);
    firebase = { app, auth, db, authModule, firestoreModule };
    firebaseConnected = true;

    authModule.onAuthStateChanged(auth, async (authUser) => {
      if (!authUser) {
        currentUser = null;
        localStorage.removeItem(USER_KEY);
        notify();
        return;
      }
      try {
        currentUser = await userDocument(authUser.uid) || normalizeUser(authUser);
        write(USER_KEY, currentUser);
        await upsertUser(currentUser);
      } catch (error) {
        rememberFirebaseError(error);
        currentUser = {
          ...normalizeUser(authUser),
          firestoreError: firebaseLastError,
        };
        write(USER_KEY, currentUser);
      }
      notify();
    });

    return firebase;
  }

  async function upsertUser(user) {
    const normalized = normalizeUser(user);
    if (!normalized) return null;
    if (firebase) {
      const { doc, setDoc, serverTimestamp } = firebase.firestoreModule;
      await setDoc(doc(firebase.db, collections.users, normalized.id), {
        email: normalized.email,
        country: normalized.country,
        subscription: normalized.subscription || "FREE",
        promoCode: normalized.promoCode,
        role: normalized.role,
        createdAt: normalized.createdAt || serverTimestamp(),
        isAdmin: normalized.isAdmin,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } else {
      const users = localCollection(collections.users).filter((row) => row.id !== normalized.id);
      users.push(normalized);
      saveLocalCollection(collections.users, users);
    }
    return normalized;
  }

  async function userDocument(userId) {
    if (!firebase || !userId) return null;
    const { doc, getDoc } = firebase.firestoreModule;
    const snapshot = await getDoc(doc(firebase.db, collections.users, userId));
    if (!snapshot.exists()) return null;
    return normalizeUser({ id: userId, ...snapshot.data() });
  }

  async function register(email, password, options = {}) {
    await loadFirebase();
    const userCountry = options.country || localStorage.getItem("adprono.country") || "other";
    localStorage.setItem("adprono.country", userCountry);
    if (firebase) {
      const credential = await firebase.authModule.createUserWithEmailAndPassword(firebase.auth, email, password);
      currentUser = normalizeUser({
        uid: credential.user.uid,
        email: credential.user.email,
        country: userCountry,
        subscription: "FREE",
        createdAt: new Date().toISOString(),
      });
    } else {
      currentUser = normalizeUser({ id: `local-${email}`, email, country: userCountry });
    }
    write(USER_KEY, currentUser);
    try {
      await upsertUser(currentUser);
    } catch (error) {
      currentUser = { ...currentUser, firestoreError: rememberFirebaseError(error) };
      write(USER_KEY, currentUser);
      notify();
      throw error;
    }
    notify();
    return currentUser;
  }

  async function login(email, password) {
    await loadFirebase();
    if (firebase) {
      const credential = await firebase.authModule.signInWithEmailAndPassword(firebase.auth, email, password);
      currentUser = await userDocument(credential.user.uid) || normalizeUser(credential.user);
    } else {
      const existing = localCollection(collections.users).find((row) => row.email === email);
      currentUser = normalizeUser(existing || { id: `local-${email}`, email });
    }
    write(USER_KEY, currentUser);
    try {
      await upsertUser(currentUser);
    } catch (error) {
      currentUser = { ...currentUser, firestoreError: rememberFirebaseError(error) };
      write(USER_KEY, currentUser);
      notify();
      throw error;
    }
    notify();
    return currentUser;
  }

  async function logout() {
    await loadFirebase();
    if (firebase) await firebase.authModule.signOut(firebase.auth);
    currentUser = null;
    localStorage.removeItem(USER_KEY);
    notify();
  }

  async function resetPassword(email) {
    await loadFirebase();
    if (firebase) return firebase.authModule.sendPasswordResetEmail(firebase.auth, email);
    return true;
  }

  async function saveSubscription(plan = "PRO", mode = "monthly") {
    const user = currentUser || normalizeUser({ email: "guest@adprono.local" });
    const subscription = {
      id: `${user.id}-${plan}`,
      userId: user.id,
      plan,
      mode,
      status: "active",
      renewsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    };
    if (firebase) {
      const { doc, setDoc, serverTimestamp } = firebase.firestoreModule;
      await setDoc(doc(firebase.db, collections.subscriptions, subscription.id), {
        ...subscription,
        createdAt: serverTimestamp(),
      }, { merge: true });
      await setDoc(doc(firebase.db, collections.users, user.id), {
        subscription: plan,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } else {
      const rows = localCollection(collections.subscriptions).filter((row) => row.id !== subscription.id);
      rows.push(subscription);
      saveLocalCollection(collections.subscriptions, rows);
    }
    currentUser = { ...user, subscription: plan };
    write(USER_KEY, currentUser);
    notify();
    return subscription;
  }

  async function saveFavorites(favorites) {
    const user = currentUser || normalizeUser({ email: "guest@adprono.local" });
    const payload = {
      id: user.id,
      userId: user.id,
      ...favorites,
      updatedAt: new Date().toISOString(),
    };
    if (firebase) {
      const { doc, setDoc, serverTimestamp } = firebase.firestoreModule;
      await setDoc(doc(firebase.db, collections.favorites, user.id), {
        ...payload,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } else {
      const rows = localCollection(collections.favorites).filter((row) => row.id !== payload.id);
      rows.push(payload);
      saveLocalCollection(collections.favorites, rows);
    }
    return payload;
  }

  async function addNotification(notification) {
    const user = currentUser || normalizeUser({ email: "guest@adprono.local" });
    const payload = {
      id: `notif-${Date.now()}`,
      userId: user.id,
      unread: true,
      createdAt: new Date().toISOString(),
      ...notification,
    };
    if (firebase) {
      const { doc, setDoc, serverTimestamp } = firebase.firestoreModule;
      await setDoc(doc(firebase.db, collections.notifications, payload.id), {
        ...payload,
        createdAt: serverTimestamp(),
      });
    } else {
      const rows = localCollection(collections.notifications);
      rows.unshift(payload);
      saveLocalCollection(collections.notifications, rows);
    }
    return payload;
  }

  async function publishExpertPick(pick) {
    const user = currentUser;
    if (!user?.isAdmin) throw new Error("Admin only");
    const payload = {
      id: `expert-${Date.now()}`,
      access: "PRO",
      source: "Admin",
      createdAt: new Date().toISOString(),
      ...pick,
    };
    if (firebase) {
      const { doc, setDoc, serverTimestamp } = firebase.firestoreModule;
      await setDoc(doc(firebase.db, collections.expertPicks, payload.id), {
        ...payload,
        createdAt: serverTimestamp(),
      });
    } else {
      const rows = localCollection(collections.expertPicks);
      rows.unshift(payload);
      saveLocalCollection(collections.expertPicks, rows);
    }
    return payload;
  }

  function onAuthStateChanged(listener) {
    listeners.add(listener);
    listener(currentUser);
    return () => listeners.delete(listener);
  }

  function isPro() {
    return currentUser?.subscription === "PRO" || currentUser?.isAdmin;
  }

  function isAdmin() {
    return Boolean(currentUser?.isAdmin || currentUser?.role === "admin");
  }

  window.ADPronoFirebase = {
    collections,
    hasFirebaseConfig,
    isConnected: () => firebaseConnected,
    getLastError: () => firebaseLastError,
    init: loadFirebase,
    getCurrentUser: () => currentUser,
    onAuthStateChanged,
    register,
    login,
    logout,
    resetPassword,
    saveSubscription,
    saveFavorites,
    addNotification,
    publishExpertPick,
    isPro,
    isAdmin,
  };

  loadFirebase().catch(() => {
    firebase = null;
  });
})();
