(function () {
  const BASE_URL = "https://api.the-odds-api.com/v4";
  const REFRESH_MS = 60000;
  const SPORT_KEYS = [
    "soccer_epl",
    "soccer_spain_la_liga",
    "soccer_italy_serie_a",
    "soccer_germany_bundesliga",
    "soccer_france_ligue_one",
    "soccer_uefa_champs_league",
    "soccer_fifa_world_cup",
  ];

  let apiKey = "";

  async function loadKey() {
    if (apiKey) return apiKey;
    if (window.__AD_PRONO_ODDS_API_KEY__) {
      apiKey = window.__AD_PRONO_ODDS_API_KEY__;
      return apiKey;
    }

    const response = await fetch(".env", { cache: "no-store" });
    if (!response.ok) throw new Error("Missing .env");
    const envText = await response.text();
    apiKey = envText.match(/^VITE_ODDS_API_KEY=(.+)$/m)?.[1]?.trim() || "";
    if (!apiKey) throw new Error("Missing VITE_ODDS_API_KEY");
    return apiKey;
  }

  function normalizeName(value) {
    return String(value || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\b(fc|cf|sc|afc|ac|club|de|la|the)\b/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function namesMatch(a, b) {
    const left = normalizeName(a);
    const right = normalizeName(b);
    if (!left || !right) return false;
    return left === right;
  }

  function decimal(value) {
    return Number(value).toFixed(2);
  }

  function bestOutcome(outcomes, nameMatcher) {
    return outcomes
      .filter((outcome) => nameMatcher(outcome))
      .sort((a, b) => Number(b.price) - Number(a.price))[0];
  }

  function bestH2h(event) {
    let best = null;
    const bestBySide = { home: null, draw: null, away: null };
    event.bookmakers.forEach((bookmaker) => {
      const market = bookmaker.markets.find((item) => item.key === "h2h");
      if (!market) return;
      const home = bestOutcome(market.outcomes, (outcome) => namesMatch(outcome.name, event.home_team));
      const draw = bestOutcome(market.outcomes, (outcome) => normalizeName(outcome.name) === "draw");
      const away = bestOutcome(market.outcomes, (outcome) => namesMatch(outcome.name, event.away_team));
      [
        ["home", home],
        ["draw", draw],
        ["away", away],
      ].forEach(([side, outcome]) => {
        if (!outcome) return;
        if (!bestBySide[side] || Number(outcome.price) > Number(bestBySide[side].odds)) {
          bestBySide[side] = {
            label: side === "home" ? "1" : side === "away" ? "2" : "X",
            odds: decimal(outcome.price),
            bookmaker: bookmaker.title,
            lastUpdated: bookmaker.last_update,
          };
        }
      });
      [home, draw, away].forEach((outcome) => {
        if (!outcome) return;
        if (!best || Number(outcome.price) > Number(best.price)) {
          best = {
            label: namesMatch(outcome.name, event.home_team) ? "1" : namesMatch(outcome.name, event.away_team) ? "2" : "X",
            odds: decimal(outcome.price),
            bookmaker: bookmaker.title,
            lastUpdated: bookmaker.last_update,
          };
        }
      });
    });
    return { best, all: bestBySide };
  }

  function bestTotals(event) {
    let best = null;
    event.bookmakers.forEach((bookmaker) => {
      const market = bookmaker.markets.find((item) => item.key === "totals");
      if (!market) return;
      const over25 = market.outcomes.find((outcome) => outcome.name === "Over" && Number(outcome.point) === 2.5);
      const under25 = market.outcomes.find((outcome) => outcome.name === "Under" && Number(outcome.point) === 2.5);
      [over25, under25].forEach((outcome) => {
        if (!outcome) return;
        if (!best || Number(outcome.price) > Number(best.odds)) {
          best = {
            label: `${outcome.name === "Over" ? "Over" : "Under"} 2.5`,
            odds: decimal(outcome.price),
            bookmaker: bookmaker.title,
            lastUpdated: bookmaker.last_update,
          };
        }
      });
    });
    return best;
  }

  function bestSpread(event) {
    let best = null;
    event.bookmakers.forEach((bookmaker) => {
      const market = bookmaker.markets.find((item) => item.key === "spreads");
      if (!market) return;
      market.outcomes.forEach((outcome) => {
        if (!best || Number(outcome.price) > Number(best.odds)) {
          best = {
            label: `${outcome.name} ${outcome.point > 0 ? "+" : ""}${outcome.point}`,
            odds: decimal(outcome.price),
            bookmaker: bookmaker.title,
            lastUpdated: bookmaker.last_update,
          };
        }
      });
    });
    return best;
  }

  function normalizeEvent(event, sportKey) {
    const h2h = bestH2h(event);
    return {
      id: event.id,
      sportKey,
      commenceTime: event.commence_time,
      homeTeam: event.home_team,
      awayTeam: event.away_team,
      h2h: h2h.best,
      h2hAll: h2h.all,
      totals: bestTotals(event),
      spreads: bestSpread(event),
    };
  }

  async function fetchSportOdds(sportKey) {
    const key = await loadKey();
    const url = new URL(`${BASE_URL}/sports/${sportKey}/odds`);
    url.searchParams.set("apiKey", key);
    url.searchParams.set("regions", "us,eu");
    url.searchParams.set("markets", "h2h,totals,spreads");
    url.searchParams.set("oddsFormat", "decimal");
    url.searchParams.set("dateFormat", "iso");

    const response = await fetch(url);
    if (!response.ok) throw new Error(`The Odds API ${sportKey} ${response.status}`);
    const events = await response.json();
    return events.map((event) => normalizeEvent(event, sportKey));
  }

  async function fetchAllOdds() {
    const settled = await Promise.allSettled(SPORT_KEYS.map(fetchSportOdds));
    const odds = settled.flatMap((result) => (result.status === "fulfilled" ? result.value : []));
    if (!odds.length) {
      const rejected = settled.find((result) => result.status === "rejected");
      if (rejected) throw rejected.reason;
    }
    return {
      odds,
      lastUpdated: new Date().toISOString(),
      sportKeys: SPORT_KEYS,
    };
  }

  window.ADPronoOddsApi = {
    fetchAllOdds,
    namesMatch,
    normalizeName,
    refreshMs: REFRESH_MS,
    sportKeys: SPORT_KEYS,
  };
})();
