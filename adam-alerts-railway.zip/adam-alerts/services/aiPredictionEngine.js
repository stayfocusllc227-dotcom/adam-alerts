(function () {
  function riskLevel(confidence) {
    if (confidence >= 90) return "Très faible";
    if (confidence >= 75) return "Faible";
    if (confidence >= 60) return "Moyen";
    return "Élevé";
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function impliedProbability(odds) {
    const value = Number(odds);
    return value > 1 ? 1 / value : 0;
  }

  function normalizeMarket(h2hAll) {
    if (!h2hAll) return {};
    const raw = {
      home: impliedProbability(h2hAll.home?.odds),
      draw: impliedProbability(h2hAll.draw?.odds),
      away: impliedProbability(h2hAll.away?.odds),
    };
    const total = raw.home + raw.draw + raw.away || 1;
    return {
      home: raw.home / total,
      draw: raw.draw / total,
      away: raw.away / total,
    };
  }

  function pick1x2(homeScore, awayScore, drawScore) {
    if (homeScore >= awayScore && homeScore >= drawScore) return "1";
    if (awayScore >= homeScore && awayScore >= drawScore) return "2";
    return "X";
  }

  function bookmakerFavorite(h2hAll) {
    const prices = [
      { pick: "1", label: "victoire locale", odds: Number(h2hAll?.home?.odds) },
      { pick: "X", label: "match nul", odds: Number(h2hAll?.draw?.odds) },
      { pick: "2", label: "victoire extérieure", odds: Number(h2hAll?.away?.odds) },
    ].filter((item) => Number.isFinite(item.odds) && item.odds > 1);
    return prices.sort((a, b) => a.odds - b.odds)[0] || null;
  }

  function formScore(form, side) {
    const sideWins = side === "home" ? form.homeWins || 0 : form.awayWins || 0;
    const goalBalance = (form.goalsFor || 0) - (form.goalsAgainst || 0);
    return (form.wins || 0) * 5 + sideWins * 4 + goalBalance * 1.8 + (form.scoredMatches || 0) * 1.2;
  }

  function doubleChance(prediction, homeScore, awayScore) {
    if (prediction === "1") return homeScore - awayScore > 18 ? "1" : "1X";
    if (prediction === "2") return awayScore - homeScore > 18 ? "2" : "X2";
    return homeScore >= awayScore ? "1X" : "X2";
  }

  function handicapPick(prediction, confidence) {
    if (prediction === "1") return confidence >= 78 ? "1 (-0.5)" : "1 (0)";
    if (prediction === "2") return confidence >= 78 ? "2 (-0.5)" : "2 (0)";
    return "X (+0.5)";
  }

  function totalGoalsPick(totalGoals, odds) {
    if (odds?.totals?.label?.startsWith("Over")) return odds.totals.label;
    if (totalGoals >= 3.1) return "Over 2.5";
    if (totalGoals >= 2.25) return "Over 1.5";
    return "";
  }

  function marketConfidence(baseConfidence, adjustment = 0) {
    return clamp(Math.round(baseConfidence + adjustment), 42, 94);
  }

  function sentenceForTrend(context, prediction, confidence, favorite) {
    const homeWins = context.homeForm?.wins ?? 0;
    const awayWins = context.awayForm?.wins ?? 0;
    const h2h = context.h2h || {};
    const homeAttack = context.homeForm?.goalsFor ?? 0;
    const awayDefense = context.awayForm?.goalsAgainst ?? 0;
    const favoriteText = favorite
      ? `Le favori bookmaker est ${favorite.pick} (${favorite.odds.toFixed(2)}).`
      : "Aucune cote 1X2 fiable n'est disponible, l'IA se base davantage sur la forme récente.";
    const h2hText = h2h.matches
      ? `Le face-à-face récent indique ${h2h.homeWins || 0} victoire(s) côté local, ${h2h.awayWins || 0} côté extérieur et ${h2h.draws || 0} nul(s).`
      : "Le face-à-face récent est limité.";

    if (prediction === "1") {
      return `${favoriteText} Le club local a remporté ${homeWins} de ses 5 derniers matchs et possède une attaque plus active (${homeAttack} buts récents). ${h2hText}`;
    }
    if (prediction === "2") {
      return `${favoriteText} L'équipe à l'extérieur arrive avec ${awayWins} victoire(s) récente(s), tandis que l'adversaire a concédé ${awayDefense} but(s) sur la période. ${h2hText}`;
    }
    return `${favoriteText} Les deux équipes affichent des indicateurs proches, avec une confiance de ${confidence}% et un équilibre visible entre forme récente et H2H. ${h2hText}`;
  }

  function generate(context) {
    const homeForm = context.homeForm || {};
    const awayForm = context.awayForm || {};
    const homeStanding = context.homeStanding || {};
    const awayStanding = context.awayStanding || {};
    const h2h = context.h2h || {};
    const market = normalizeMarket(context.odds?.h2hAll);
    const favorite = bookmakerFavorite(context.odds?.h2hAll);
    const hasBookmakerMarket = !!favorite;

    const homeGoalBalance = (homeForm.goalsFor || 0) - (homeForm.goalsAgainst || 0);
    const awayGoalBalance = (awayForm.goalsFor || 0) - (awayForm.goalsAgainst || 0);
    const rankEdge = (awayStanding.rank || 24) - (homeStanding.rank || 24);
    const marketWeight = hasBookmakerMarket ? 72 : 32;
    const formWeight = 1.35;
    const h2hWeight = 5.5;
    const marketHome = (market.home || 0.33) * marketWeight;
    const marketDraw = (market.draw || 0.28) * marketWeight;
    const marketAway = (market.away || 0.33) * marketWeight;

    const homeScore =
      marketHome +
      formScore(homeForm, "home") * formWeight +
      rankEdge * 0.8 +
      (h2h.homeWins || 0) * h2hWeight;
    const awayScore =
      marketAway +
      formScore(awayForm, "away") * formWeight -
      rankEdge * 0.8 +
      (h2h.awayWins || 0) * h2hWeight;
    const drawScore =
      marketDraw +
      (homeForm.draws || 0) * 3 +
      (awayForm.draws || 0) * 3 +
      Math.max(0, 8 - Math.abs(homeGoalBalance - awayGoalBalance)) +
      (h2h.draws || 0) * h2hWeight;

    const rawPrediction = pick1x2(homeScore, awayScore, drawScore);
    const scoreByPick = { 1: homeScore, X: drawScore, 2: awayScore };
    const topRawScore = scoreByPick[rawPrediction];
    const favoriteScore = favorite ? scoreByPick[favorite.pick] : 0;
    const prediction = favorite && topRawScore - favoriteScore <= 14 ? favorite.pick : rawPrediction;
    const topScore = Math.max(homeScore, awayScore, drawScore);
    const secondScore = [homeScore, awayScore, drawScore].sort((a, b) => b - a)[1];
    const favoriteAligned = favorite?.pick === prediction;
    const confidence = clamp(
      Math.round(
        48 +
          (topScore - secondScore) * 1.15 +
          Math.max(market.home || 0, market.away || 0, market.draw || 0) * 34 +
          (favoriteAligned ? 8 : -6),
      ),
      42,
      96,
    );
    const totalGoals =
      ((homeForm.goalsFor || 0) + (awayForm.goalsFor || 0) + (homeForm.goalsAgainst || 0) + (awayForm.goalsAgainst || 0)) / 5;
    const overUnder25 = totalGoalsPick(totalGoals, context.odds);
    const btts = (homeForm.scoredMatches || 0) >= 3 && (awayForm.scoredMatches || 0) >= 3 ? "Oui" : "Non";
    const dcPick = doubleChance(prediction, homeScore, awayScore);
    const handicap = handicapPick(prediction, confidence);
    const bttsConfidence = marketConfidence(confidence, btts === "Oui" ? -4 : -7);
    const totalConfidence = overUnder25 ? marketConfidence(confidence, totalGoals >= 2.7 ? 4 : -5) : 0;
    const handicapConfidence = marketConfidence(confidence, favoriteAligned ? -2 : -8);

    return {
      oneXTwo: prediction,
      doubleChance: dcPick,
      btts,
      overUnder25,
      totalGoals: overUnder25,
      handicap,
      confidence,
      risk: riskLevel(confidence),
      explanation: sentenceForTrend(context, prediction, confidence, favorite),
      marketProbabilities: market,
      bookmakerFavorite: favorite,
      analysisOrder: ["Cote bookmaker favorite", "5 derniers matchs des équipes", "5 derniers face-à-face"],
      marketAnalysis: {
        doubleChance: {
          pick: dcPick,
          confidence: marketConfidence(confidence, 6),
          explanation: `Sélection plus protégée basée sur le pick 1X2 ${prediction}, la forme récente et le face-à-face.`,
        },
        btts: {
          pick: btts,
          confidence: bttsConfidence,
          explanation: btts === "Oui"
            ? "Les deux équipes marquent régulièrement sur leurs 5 derniers matchs."
            : "Au moins une équipe montre un signal offensif plus faible sur les 5 derniers matchs.",
        },
        totalGoals: {
          pick: overUnder25,
          confidence: totalConfidence,
          explanation: overUnder25
            ? `La moyenne récente estimée est de ${totalGoals.toFixed(1)} buts, ajustée avec le marché bookmaker.`
            : `La moyenne récente estimée est de ${totalGoals.toFixed(1)} buts; l'IA évite Under et privilégie Double Chance ou Handicap.`,
        },
        handicap: {
          pick: handicap,
          confidence: handicapConfidence,
          explanation: favorite
            ? `Le handicap suit le favori bookmaker ${favorite.pick} avec prudence selon la forme et le H2H.`
            : "Handicap calculé avec prudence car les cotes bookmaker sont limitées.",
        },
      },
    };
  }

  window.ADPronoAiEngine = {
    generate,
    riskLevel,
  };
})();
