window.AD_PRONO_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCaZ_lJ2zksw8yc3ZbbufG9uzFXJm8BOeA",
  authDomain: "ad-prono.firebaseapp.com",
  projectId: "ad-prono",
  storageBucket: "ad-prono.firebasestorage.app",
  messagingSenderId: "61525310124",
  appId: "1:61525310124:web:166e2286927c424a783d09",
  measurementId: "G-XBCV7NDKX8",
};

window.AD_PRONO_ADMIN_EMAILS = [
  // Remplace cette adresse par ton email Firebase/Auth exact pour activer le role admin.
  "admin@adprono.com",
];
