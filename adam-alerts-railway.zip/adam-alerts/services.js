export const firebaseSchema = {
  users: {
    id: "string",
    email: "string",
    country: "haiti | usa | other",
    subscription: "FREE | PRO | VIP | ELITE",
    createdAt: "timestamp",
  },
  subscriptions: {
    userId: "string",
    plan: "FREE | PRO | VIP | ELITE",
    provider: "MonCash | NatCash | Stripe | PayPal",
    status: "active | past_due | canceled",
    renewsAt: "timestamp",
  },
  predictions: {
    fixtureId: "string",
    source: "AI",
    access: "FREE",
    prediction: "1 | X | 2",
    confidence: "number",
    risk: "Faible | Moyen | Élevé",
    explanation: "string",
  },
  expert_picks: {
    fixtureId: "string",
    source: "Expert",
    access: "PRO | VIP",
    expertName: "string",
    expertWinRate: "number",
    note: "string",
  },
  favorites: {
    userId: "string",
    teams: "string[]",
    leagues: "string[]",
    predictions: "string[]",
  },
  notifications: {
    userId: "string",
    type: "vip_pick | match_start | odds_change | winning_prediction",
    title: "string",
    body: "string",
    unread: "boolean",
    createdAt: "timestamp",
  },
};

export const integrationConfig = {
  apiFootball: {
    baseUrl: "https://v3.football.api-sports.io",
    apiKeyEnv: "API_FOOTBALL_KEY",
    refreshMs: 60000,
    endpoints: {
      liveMatches: "/fixtures?live=all",
      upcomingFixtures: "/fixtures?next=50",
      standings: "/standings",
      leagues: "/leagues",
      teams: "/teams",
      worldCup2026: "/fixtures?league=1&season=2026",
    },
  },
  oddsApi: {
    baseUrl: "https://api.the-odds-api.com/v4",
    apiKeyEnv: "THE_ODDS_API_KEY",
    refreshMs: 60000,
    markets: ["h2h", "totals", "btts"],
  },
};

export const paymentConfig = {
  haiti: {
    currency: "HTG",
    proPrice: 150,
    methods: ["MonCash", "NatCash"],
  },
  usa: {
    currency: "USD",
    proPrice: 9.99,
    methods: ["Stripe", "PayPal", "Apple Pay", "Google Pay"],
  },
  other: {
    currency: "USD",
    proPrice: 9.99,
    methods: ["Stripe", "PayPal", "Visa/Mastercard"],
  },
};

export const notificationTypes = {
  newVipPick: "New VIP pick",
  matchStartingSoon: "Match starting soon",
  winningPrediction: "Winning prediction",
  oddsChange: "Odds change",
};

export const accessRules = {
  aiPicks: "FREE",
  expertPicks: "PRO",
  vipPicks: "VIP",
};

export function generateAiPrediction(input) {
  const formScore = input.last5Wins * 9;
  const rankingScore = Math.max(0, 25 - input.ranking);
  const homeAwayScore = input.homeAwayForm * 4;
  const goalsScore = Math.max(0, input.goalsScored - input.goalsConceded) * 5;
  const h2hScore = input.headToHeadWins * 4;
  const oddsScore = input.oddsMovement > 0 ? 8 : -4;
  const confidence = Math.max(
    35,
    Math.min(92, Math.round(38 + formScore + rankingScore + homeAwayScore + goalsScore + h2hScore + oddsScore)),
  );
  const risk = confidence >= 72 ? "Faible" : confidence >= 58 ? "Moyen" : "Élevé";
  const prediction = confidence >= 68 ? "1" : confidence >= 55 ? "1X" : "X";

  return {
    prediction,
    confidence,
    risk,
    explanation:
      "L'équipe locale reste performante sur ses 5 derniers matchs, présente une meilleure dynamique offensive et bénéficie d'un mouvement de cote favorable.",
  };
}
