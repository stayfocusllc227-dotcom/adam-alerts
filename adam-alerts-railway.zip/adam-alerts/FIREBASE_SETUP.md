# AD PRONO Firebase Setup

AD PRONO is prepared as a production-first web app with Firebase-ready services.

## Firebase config

Create a Firebase web app, then paste the config values into:

- `firebase-config.js` for browser runtime
- `.env` if you later migrate to Vite build-time injection

Required fields:

- `apiKey`
- `authDomain`
- `projectId`
- `storageBucket`
- `messagingSenderId`
- `appId`

## Collections

- `users`
- `subscriptions`
- `favorites`
- `notifications`
- `expert_picks`
- `promo_codes`

## Admin access

Add admin emails in `firebase-config.js`:

```js
window.AD_PRONO_ADMIN_EMAILS = [
  "admin@adprono.com",
];
```

## PWA

The web app is installable through:

- `manifest.webmanifest`
- `sw.js`
- `assets/ad-prono-logo.jpg`

Launch as web/PWA first. Native iOS/Android can come later.
