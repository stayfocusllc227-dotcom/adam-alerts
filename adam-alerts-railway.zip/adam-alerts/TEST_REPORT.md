# AD PRONO - Test Report

Date: 2026-06-12
Environment: local app at `http://127.0.0.1:4173/#home`

## Visual Polish

- Status: PASS
- Typography was increased across the mobile app:
  - Team names
  - League names
  - Prediction boxes
  - Odds lines
  - AI cards
  - Subscription cards
  - Notifications
  - Bottom navigation
- Note: no video file was available in the current message, so the typography update was based on the visible AD PRONO app and the request that the text was too small.

## Testing Checklist

1. AI predictions generate correctly
   - Status: PASS
   - Observed `🤖 IA Pick`, confidence %, risk level, 1X2, double chance, BTTS, Over/Under 2.5 and French explanation.

2. Odds match the correct teams
   - Status: PASS
   - Odds now require home team match, away team match and kickoff time within 3 hours.
   - Debug panels show matched/not matched state.

3. Country pricing works
   - Status: PASS
   - Country selector changes subscription pricing.

4. Haiti users see Gourdes pricing
   - Status: PASS
   - Verified: `150 GDES / mois`, `MonCash`, `NatCash`.

5. USA users see USD pricing
   - Status: PASS
   - Verified: `$9.99 / mois`, `Stripe`, `PayPal`, `Apple Pay`.

6. PRO content locks correctly
   - Status: PARTIAL
   - PRO page is separated from AI picks and only accepts Expert/Admin picks.
   - Current live API feed has no manually published Expert/Admin PRO picks, so lock behavior needs seeded PRO content for full verification.

7. VIP content locks correctly
   - Status: PARTIAL
   - VIP page exists and is separated from AI/PRO content.
   - Current live API feed has no VIP Expert picks, so full lock verification needs seeded VIP content.

8. Favorites save correctly
   - Status: PASS
   - Verified by favoriting a match and reloading. Favorite stayed active.

9. Notifications work
   - Status: UI PASS / PUSH PARTIAL
   - Notifications page renders 5 notification types with unread badge.
   - Real push delivery still requires Firebase/notification backend.

10. No duplicate matches
   - Status: PASS
   - Home feed duplicate count: `0`.

11. No broken logos
   - Status: PASS
   - Checked visible home logos. Broken image count: `0`.

12. Mobile responsiveness
   - Status: PASS
   - Tested widths:
     - 360px Android narrow
     - 393px iPhone width
     - 768px tablet
     - 1280px desktop
   - No horizontal overflow observed.

13. World Cup page
   - Status: PASS
   - World Cup 2026 page loads fixtures, groups, standings section, predictions and match list.

14. Experts page
   - Status: PASS
   - Experts page renders 3 expert profiles with win rate, ROI/followers and rankings.

15. Subscription page
   - Status: PASS
   - Subscription page renders FREE, PRO, VIP and ELITE plans with country-based pricing.

## API Checks

- API-Football: PASS
  - Badge: `API-Football Connected`
  - Live matches visible
  - Real team logos visible
  - Real league logos visible

- The Odds API: PASS
  - Badge: `The Odds API Connected`
  - Odds are displayed only after strict team/time matching.
  - If odds are not matched, UI shows `Cote indisponible`.

## Responsive Audit

- Android narrow 360px:
  - App width: 360px
  - Overflow: false

- iPhone width 393px:
  - App width: 393px
  - Overflow: false

- Tablet 768px:
  - App width: 393px
  - Overflow: false

- Desktop 1280px:
  - App width: 393px
  - Overflow: false

## Notes

- The app is visually closer to a native mobile betting prediction app after increasing font sizes.
- PRO/VIP lock testing needs real seeded Expert/Admin picks because the current real API match feed generates AI/free predictions only.
- Push notifications and paid access enforcement still need backend/Firebase integration for production.
