# ADAM Alerts Telegram System

Node.js worker for automatic football betting alerts in Telegram.

## Run

```bash
npm run alerts
```

One-off checks:

```bash
npm run alerts:once
npm run alerts:daily
```

Use `DRY_RUN=true npm run alerts:daily` to preview output without posting to Telegram.

Health check:

```bash
curl http://localhost:3000/health
```

## What It Does

- Posts daily best bets at 8 AM in `TIMEZONE`.
- Polls API-Football live fixtures every 60 seconds for goals and red cards.
- Polls The Odds API for significant odds changes.
- Prioritizes World Cup markets when `WORLD_CUP_MODE=true`.
- Stores duplicate-protection state in `data/adam-alerts-state.json`.
- Exposes `/health` for uptime monitoring.
- Emits structured JSON logs for checks, alerts, duplicates, errors, and startup.

## Telegram

`TELEGRAM_CHANNEL_ID` can be a channel username like `@adambet_alert` or a `https://t.me/...` URL. The bot must be an admin in the channel before Telegram will allow posting.

## Environment

Required:

```bash
API_FOOTBALL_KEY=
ODDS_API_KEY=
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHANNEL_ID=
```

Optional:

```bash
TIMEZONE=America/New_York
WORLD_CUP_MODE=true
DAILY_BEST_BETS_HOUR=8
LIVE_POLL_SECONDS=60
ODDS_POLL_SECONDS=300
ODDS_MOVE_THRESHOLD=0.12
PORT=3000
ADAM_ALERTS_STATE_PATH=./data/adam-alerts-state.json
DRY_RUN=false
```

## Railway Deployment

Railway will run this as a long-lived web process because the worker exposes `/health`.

1. Push this project to a GitHub repository.
2. In Railway, create a new project from that GitHub repo.
3. Railway should detect Node.js through `package.json`.
4. Add these Railway variables:

```bash
API_FOOTBALL_KEY=your_api_football_key
ODDS_API_KEY=your_odds_api_key
TELEGRAM_BOT_TOKEN=your_full_bot_token
TELEGRAM_CHANNEL_ID=@adambet_alert
TIMEZONE=America/New_York
WORLD_CUP_MODE=true
DAILY_BEST_BETS_HOUR=8
LIVE_POLL_SECONDS=60
ODDS_POLL_SECONDS=300
ODDS_MOVE_THRESHOLD=0.12
DRY_RUN=false
```

5. Deploy.
6. Open the Railway service URL at `/health`.
7. Confirm the response contains `"ok": true` and `"status": "running"`.
8. Check Railway logs for structured entries like `ADAM Alerts Telegram System started` and `Live fixture check completed`.

`railway.json` configures:

- `npm start` as the start command.
- `/health` as the health check path.
- automatic restart on process failure.

For stronger duplicate protection across redeploys, attach a Railway volume and set:

```bash
ADAM_ALERTS_STATE_PATH=/data/adam-alerts-state.json
```

Without a persistent volume, duplicate state can reset on redeploys. Crash restarts usually preserve the container filesystem, but a volume is the cleaner 24/7 setup.

## 24/7 Verification

After deployment:

1. Close Codex.
2. Wait at least 2 minutes.
3. Visit `https://your-railway-service.up.railway.app/health`.
4. Confirm `uptimeSeconds` has increased and `lastLiveCheckAt` is recent.
5. Review Railway logs and confirm live checks continue every 60 seconds.

If those checks pass, ADAM Alerts is operating independently of Codex.
